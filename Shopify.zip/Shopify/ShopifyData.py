import requests
import time
import Helper
import DBUtils
import os

def get_data(access_token,api_base_url,entity_name,params,log_file_path,json_parent_attr_name=None):
    #api_url=api_base_url + r'/' + entity_name +'.json'
    api_url=api_base_url + entity_name +'.json'
    headers = {
        "X-Shopify-Access-Token": access_token
    }
    if json_parent_attr_name==None:
        json_parent_attr_name = entity_name
    try:
        iterationCnt=0
        url=api_url
        all_data = []
        retries = 0
        while url:
            # Make a request to the Shopify API
            if iterationCnt==0:
                response = requests.get(url,headers=headers,params=params)
                Helper.to_log(log_file_path,'info', f"Iteration {iterationCnt} ...")
            else:
                response = requests.get(url,headers=headers)
                Helper.to_log(log_file_path,'info', f"Iteration {iterationCnt} ...")
            
            # Check if request was successful
            if response.status_code == 200:
                # Append data from current page
                dctEntity = response.json()
                all_data.extend(dctEntity[json_parent_attr_name])
                
                # Extract pagination links from response headers
                links = response.links
                
                # Check if there's a 'next' link
                if 'next' in links:
                    url = links['next']['url']
                    iterationCnt +=1
                else:
                    url = None  # No more pages, exit loop
            elif response.status_code == 429:  # Rate limiting, retry after delay
                retry_after = int(response.headers.get('Retry-After', 0))
                retries += 1
                if retries > 5:
                    Helper.to_log(log_file_path,'info', "Max retry attempts reached. Exiting.")
                    break
                Helper.to_log(log_file_path,'info', f"Rate limited. Retrying after {retry_after} seconds...")
                time.sleep(retry_after)
            else:
                Helper.to_log(log_file_path,'info', f"Error: {response.status_code} - {response.reason}")
                break
        
        # START Code for testing
        # response = requests.get(url,headers=headers,params=params)
        # dctEntity = response.json()
        # all_data.extend(dctEntity[json_parent_attr_name])
        # END Code for testing
        return all_data
    except Exception as ex:
        # Handle exceptions
        #Helper.to_log(log_file_path,'exception', f"Exception: {ex}")
        raise

def get_count(access_token,api_base_url,entity_name,log_file_path):
    # api_url=api_base_url + r'/' + entity_name + r'/' +'count.json'
    api_url=api_base_url +  entity_name + r'/' +'count.json'
    headers = {
        "X-Shopify-Access-Token": access_token
    }
    dctEntity = {}
    count =0
    try:
        iterationCnt=0
        url=api_url
        retries = 0
        while url:
            # Make a request to the Shopify API
            response = requests.get(url,headers=headers)
            
            # Check if request was successful
            if response.status_code == 200:
                # Append data from current page
                dctEntity = response.json()
                url = None  #exit loop
            elif response.status_code == 429:  # Rate limiting, retry after delay
                retry_after = int(response.headers.get('Retry-After', 0))
                retries += 1
                if retries > 5:
                    Helper.to_log(log_file_path,'info', "Max retry attempts reached. Exiting.")
                    break
                Helper.to_log(log_file_path,'info', f"Rate limited. Retrying after {retry_after} seconds...")
                time.sleep(retry_after)
            else:
                Helper.to_log(log_file_path,'info', f"Error: {response.status_code} - {response.reason}")
                break

        count = dctEntity["count"]
        return count

    except Exception as ex:
        # Handle exceptions
        Helper.to_log(log_file_path,'exception', f"Exception: {ex}")

def get_updated_min_max_dates(site,entity_type,log_file_path):
        current_dir = os.path.dirname(__file__)
        csv_file_path = os.path.join(current_dir, "config_stg.csv")

        conn = DBUtils.get_db_connection(csv_file_path,log_file_path)
        # Example usage of inline query
        query = f'''SELECT CONVERT(NVARCHAR(30), ISNULL(MAX([updated_at_max]),'1900-01-01') , 127) 
                ,CONVERT(NVARCHAR(30), GETDATE() , 127) 
                FROM [shp].[Shopify_API_Data_Header_Info] 
                WHERE site='{site}' AND entity_type= '{entity_type}' AND data_load_status = 1'''
        rows = DBUtils.execute_inline_query(conn, query,log_file_path)
        return rows[0]

def get_config_value(config_name,log_file_path):
        current_dir = os.path.dirname(__file__)
        csv_file_path = os.path.join(current_dir, "config_stg.csv")

        conn = DBUtils.get_db_connection(csv_file_path,log_file_path)
        # Example usage of inline query
        query = f'''SELECT ConfigValue
                FROM [shp].[ShopifyConfig] 
                WHERE ConfigName='{config_name}' '''
        rows = DBUtils.execute_inline_query(conn, query,log_file_path)
        return rows[0][0]

