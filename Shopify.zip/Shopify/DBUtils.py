import pyodbc
import Helper
import pandas as pd

def load_config(filename):
    try:
        config_df = pd.read_csv(filename, header=None, index_col=0)
        config = config_df.to_dict()
        return config[1]
    except FileNotFoundError as ex:
        print("Config file not found. {ex}")
        return None

# Function to establish a database connection
def get_db_connection(config_file,log_file_path):
    config = load_config(config_file)
    if config is None:
        return None
    
    try:
        username = config.get('username')
        password = config.get('password')
        if (username is None or password is None or str(username).strip() == '' or str(password).strip() == '' or str(username).strip()=='nan' or str(password).strip() == 'nan') == False:            
            conn_str = f"DRIVER={{SQL Server}};SERVER={config['server']};DATABASE={config['database']};UID={config['username']};PWD={config['password']}"
        else:
            conn_str = f"DRIVER={{SQL Server}};SERVER={config['server']};DATABASE={config['database']};Trusted_Connection=yes"
        
        conn = pyodbc.connect(conn_str)
        return conn
    except pyodbc.Error as ex:
        if log_file_path:
            Helper.to_log(log_file_path,'exception', f"Error while connecting to the database:'{ex}'.")
        return None

# Example usage:
# conn = get_db_connection('config_stg.csv')

# Function to execute a stored procedure with dynamic parameters
def execute_stored_procedure(conn, sp_name, params,log_file_path=""):
    try:
        cursor = conn.cursor()
        param_str = ",".join(["?" for _ in params])
        cursor.execute(f"EXEC {sp_name} {param_str}", params)
        conn.commit()  # If the stored procedure modifies data, you need to commit the transaction

        rows = None
        output_params = None

        # Handling record set (if any)
        if cursor.description is not None:
            rows = cursor.fetchall()

        # Handling output parameters
        output_params = [param for param in params if isinstance(param, pyodbc.OutputParam)]

        return rows, output_params

    except pyodbc.Error as ex:
        if log_file_path:
            Helper.to_log(log_file_path,'exception', f"Error while executing stored procedure:'{ex}'.")
        return None, None

# Function to execute an inline query
def execute_inline_query(conn, query,log_file_path):
    try:
        cursor = conn.cursor()
        cursor.execute(query)
        rows = cursor.fetchall()
        return rows
    except pyodbc.Error as ex:
        if log_file_path:
            Helper.to_log(log_file_path,'exception', f"Error while executing inline query:'{ex}'.")
        return None

# Example usage
# conn = get_db_connection("config_stg","")

# if conn:
#     # Example usage of stored procedure
#     sp_name = 'YourStoredProcedure'
#     sp_params = ['value1', 'value2']  # Example parameters
#     execute_stored_procedure(conn, sp_name, sp_params)

#     # Example usage of inline query
#     query = "SELECT * FROM YourTable"
#     execute_inline_query(conn, query)

#     # Close the connection
#     conn.close()
# else:
#     print("Failed to establish a database connection.")

