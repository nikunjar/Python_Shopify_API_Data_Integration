import sys, argparse, os
from datetime import datetime
import ShopifyData, Helper
import Entity.Products as Products, Entity.SalesChannels as SalesChannels, Entity.Orders as Orders
import Entity.Discounts as Discounts, Entity.Customers as Customers, Entity.GiftCards as GiftCards
import Entity.Inventory as Inventory, Entity.Billing as Billing, Entity.Events as Events
import Entity.MarketingEvent as MarketingEvent
import Entity.OnlineStore as OnlineStore
import Entity.ShipmentFulfillment as ShipmentFulfillment
import Entity.ShopifyPayments as ShopifyPayments
import Entity.StoreProperty as StoreProperty
import Entity.TenderTransaction as TenderTransaction
import Entity.Webhooks as Webhooks

#START  Commandline arguments
parser = argparse.ArgumentParser(description='Pass site, entity_type, updated_at_min and updated_at_max as arguments')
parser.add_argument('site', type=str, help='site') #us or canada
parser.add_argument('entity_type', type=str, help='entity_type') #products, checkouts, orders etc.
parser.add_argument('--updated_at_min', type=str, help='updated_at_min') #optional parameter updated date start. When not provided, reads from database
parser.add_argument('--updated_at_max', type=str, help='updated_at_max') #optional parameter updated date end.. When not provided, reads from database

args = parser.parse_args()
site = sys.argv[1]
entity_type = sys.argv[2]
if len(sys.argv) > 3:
    updated_at_min =  sys.argv[3]
    updated_at_max =  sys.argv[4]
else:
    updated_at_min =  None
    updated_at_max =  None

#Comment following code after testing
# site = 'canada'
# entity_type = 'orders'
# updated_at_min = '2000-01-01' #'1900-01-01 11:00:11.000' 
# updated_at_max = '2019-10-24' 

save_raw = True

#END  Commandline arguments

# Build parameters
params =	{
  "limit": 250,
}
																	
data_reference_path = '\\data\\' + site + '\\landing\\'+ entity_type +'\\landed\\'
raw_reference_path = '\\data\\' + site + '\\landing\\'+ entity_type +'\\raw\\'
header_reference_path = '\\data\\' + site + '\\landing\\'+ entity_type +'\\header\\'
failed_reference_path = '\\data\\' + site + '\\landing\\'+ entity_type +'\\failed\\'
log_reference_path = '\\data\\' + site + '\\log\\'

# Get configuration values
working_directory = ShopifyData.get_config_value('working_directory',None)
# Create log file of logging
log_file_path =  Helper.create_log_file(working_directory.rstrip('\\') + log_reference_path,entity_type)

#Access API url and access token based on site
if site=='canada':
    api_base_url = ShopifyData.get_config_value('api_base_url_ca',log_file_path)
    access_token = ShopifyData.get_config_value('access_token_ca',log_file_path)
if site=='us':
    api_base_url = ShopifyData.get_config_value('api_base_url_us',log_file_path)
    access_token = ShopifyData.get_config_value('access_token_us',log_file_path)

# Get last updated_at_mean and updated_at_max values based on last data load
rows = ShopifyData.get_updated_min_max_dates(site,entity_type,log_file_path)

if updated_at_min is not None and len(updated_at_min.strip()) != 0 :
    params["updated_at_min"] = updated_at_min
else:
    updated_at_min = rows[0]
    params["updated_at_min"] = updated_at_min
if updated_at_max is not None and len(updated_at_max.strip()) != 0 :
    params["updated_at_max"] = updated_at_max
else:
    updated_at_max = rows[1]
    params["updated_at_max"] = updated_at_max

def main():
    landing_path = working_directory.rstrip('\\') + data_reference_path
    raw_file_path = working_directory.rstrip('\\') + raw_reference_path
    header_file_path = working_directory.rstrip('\\') + header_reference_path
    failed_file_path = working_directory.rstrip('\\') + failed_reference_path
    save_record_count = True
    try:
        # Create the landing folder if it doesn't exist
        if not os.path.exists(landing_path):
            os.makedirs(landing_path)
        if not os.path.exists(header_file_path):
            os.makedirs(header_file_path)

        if save_raw == True:
            # Create the landing folder if it doesn't exist
            if not os.path.exists(raw_file_path):
                os.makedirs(raw_file_path)

        Helper.move_files(landing_path,failed_file_path)
        Helper.move_files(header_file_path,failed_file_path)

        if entity_type=='products':
            file_info = Products.get_products(access_token,api_base_url,params,landing_path,save_raw,raw_file_path,log_file_path)

        # if entity_type=='collects':
        #     file_info = Products.get_collects(access_token,api_base_url,params,landing_path,save_raw,raw_file_path,log_file_path)

        if entity_type=='custom_collections':
            file_info = Products.get_custom_collections(access_token,api_base_url,params,landing_path,save_raw,raw_file_path,log_file_path)

        # if entity_type=='smart_collections':
        #     file_info = Products.get_smart_collections(access_token,api_base_url,params,landing_path,save_raw,raw_file_path,log_file_path)

        if entity_type=='checkouts':
            file_info = Orders.get_checkouts(access_token,api_base_url,params,landing_path,save_raw,raw_file_path,log_file_path)

        if entity_type=='orders':
            params["status"] = "any"
            file_info = Orders.get_orders(access_token,api_base_url,params,landing_path,save_raw,raw_file_path,log_file_path)
            
        # if entity_type=='draft_orders':   # data since 2019-07-01 # Failing with response.status_code 500. Total record count 198448.
        #     file_info = Orders.get_draft_orders(access_token,api_base_url,params,landing_path,save_raw,raw_file_path,log_file_path)

        if entity_type=='price_rules':
            file_info = Discounts.get_price_rules(access_token,api_base_url,params,landing_path,save_raw,raw_file_path,log_file_path)

        if entity_type=='customers':
            file_info = Customers.get_customers(access_token,api_base_url,params,landing_path,save_raw,raw_file_path,log_file_path)

        if entity_type=='product_listings':
            file_info = SalesChannels.get_product_listings(access_token,api_base_url,params,landing_path,save_raw,raw_file_path,log_file_path)

        if entity_type=='gift_cards':
            file_info = GiftCards.get_gift_cards(access_token,api_base_url,params,landing_path,save_raw,raw_file_path,log_file_path)

        if entity_type=='locations':
            file_info = Inventory.get_locations(access_token,api_base_url,params,landing_path,save_raw,raw_file_path,log_file_path)

        if entity_type=='application_charges':
            file_info = Billing.get_application_charges(access_token,api_base_url,params,landing_path,save_raw,raw_file_path,log_file_path)

        if entity_type=='application_credits':
            file_info = Billing.get_application_credits(access_token,api_base_url,params,landing_path,save_raw,raw_file_path,log_file_path)

        if entity_type=='recurring_application_charges':
            file_info = Billing.get_recurring_application_charges(access_token,api_base_url,params,landing_path,save_raw,raw_file_path,log_file_path)

        if entity_type=='events':
            file_info = Events.get_events(access_token,api_base_url,params,landing_path,save_raw,raw_file_path,log_file_path)
        
        if entity_type=='marketing_events':
            file_info = MarketingEvent.get_marketing_events(access_token,api_base_url,params,landing_path,save_raw,raw_file_path,log_file_path)    
        
        # if entity_type=='blogs':
        #     file_info = OnlineStore.get_blogs(access_token,api_base_url,params,landing_path,save_raw,raw_file_path,log_file_path)    

        if entity_type=='pages':
            file_info = OnlineStore.get_pages(access_token,api_base_url,params,landing_path,save_raw,raw_file_path,log_file_path)

        # if entity_type=='redirects':
        #     file_info = OnlineStore.get_redirects(access_token,api_base_url,params,landing_path,save_raw,raw_file_path,log_file_path)

        # if entity_type=='script_tags':
        #     file_info = OnlineStore.get_script_tags(access_token,api_base_url,params,landing_path,save_raw,raw_file_path,log_file_path)

        # if entity_type=='themes':
        #     file_info = OnlineStore.get_themes(access_token,api_base_url,params,landing_path,save_raw,raw_file_path,log_file_path)

        if entity_type=='carrier_services':
            file_info = ShipmentFulfillment.get_carrier_services(access_token,api_base_url,params,landing_path,save_raw,raw_file_path,log_file_path)

        if entity_type=='fulfillment_services':
            file_info = ShipmentFulfillment.get_fulfillment_services(access_token,api_base_url,params,landing_path,save_raw,raw_file_path,log_file_path)

        if entity_type=='disputes':
            file_info = ShopifyPayments.get_disputes(access_token,api_base_url,params,landing_path,save_raw,raw_file_path,log_file_path)

        if entity_type=='payouts':
            file_info = ShopifyPayments.get_payouts(access_token,api_base_url,params,landing_path,save_raw,raw_file_path,log_file_path)

        if entity_type=='countries':
            file_info = StoreProperty.get_countries(access_token,api_base_url,params,landing_path,save_raw,raw_file_path,log_file_path)

        if entity_type=='currencies':
            file_info = StoreProperty.get_currencies(access_token,api_base_url,params,landing_path,save_raw,raw_file_path,log_file_path)

        if entity_type=='policies':
            file_info = StoreProperty.get_policies(access_token,api_base_url,params,landing_path,save_raw,raw_file_path,log_file_path)

        if entity_type=='shipping_zones':
            file_info = StoreProperty.get_shipping_zones(access_token,api_base_url,params,landing_path,save_raw,raw_file_path,log_file_path)
            save_record_count = False

        if entity_type=='tender_transactions':
            file_info = TenderTransaction.get_tender_transactions(access_token,api_base_url,params,landing_path,save_raw,raw_file_path,log_file_path)

        if entity_type=='webhooks':
            file_info = Webhooks.get_webhooks(access_token,api_base_url,params,landing_path,save_raw,raw_file_path,log_file_path)
		
        save_header_info(file_info,header_file_path,save_record_count)

    except PermissionError:
        Helper.to_log(log_file_path,'exception', f"Permission error: Unable to create directory '{landing_path}'.")
        Helper.move_files(landing_path,failed_file_path)
        Helper.move_files(header_file_path,failed_file_path)
    except FileNotFoundError:
        Helper.to_log(log_file_path,'exception', f"File not found error: Unable to create directory '{landing_path}'.")
        Helper.move_files(landing_path,failed_file_path)
        Helper.move_files(header_file_path,failed_file_path)
    except FileExistsError:
        Helper.to_log(log_file_path,'exception', f"Directory '{landing_path}' already exists.")
        Helper.move_files(landing_path,failed_file_path)
        Helper.move_files(header_file_path,failed_file_path)
    except OSError as e:
        Helper.to_log(log_file_path,'exception', f"Error creating directory '{landing_path}': {e}")
        Helper.move_files(landing_path,failed_file_path)
        Helper.move_files(header_file_path,failed_file_path)
    except TypeError as e:
        Helper.to_log(log_file_path,'exception', f"Type error: {e}")
        Helper.move_files(landing_path,failed_file_path)
        Helper.move_files(header_file_path,failed_file_path)
    except UnicodeEncodeError as e:
        Helper.to_log(log_file_path,'exception', "Unicode encode error: {e}")
        Helper.move_files(landing_path,failed_file_path)
        Helper.move_files(header_file_path,failed_file_path)
    except Exception as e:
        Helper.to_log(log_file_path,'exception', f"An unexpected error occurred: {e}")
        Helper.move_files(landing_path,failed_file_path)
        Helper.move_files(header_file_path,failed_file_path)

def save_header_info(file_info,header_file_path,save_record_count):
    header_info={}
    header_info['working_directory'] = working_directory
    header_info['site'] = site
    header_info['entity_type'] = entity_type
    header_info['updated_at_min'] = updated_at_min
    header_info['updated_at_max'] = updated_at_max
    header_info.update(file_info)
    header_info['log_file_path'] = log_file_path

    total_count=0
    try:
        if save_record_count==True:
            total_count = ShopifyData.get_count(access_token,api_base_url,entity_type,log_file_path)
        else:
            total_count=0
    finally:
        header_info['total_count'] = total_count
    json_header_file_name = Helper.to_json(header_info,header_file_path,'header')
    xml_header_file_name = json_header_file_name[:-len('.json')] + '.xml'
    Helper.to_xml(header_info,header_file_path,xml_header_file_name,['site','entity_type','updated_at_min','updated_at_max','files','incremental_load_record_count','total_count'])

if __name__ == "__main__":
    Helper.to_log(log_file_path,'info', f"Script started at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    main()
    Helper.to_log(log_file_path,'info', f"Script ended at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")