import logging
from datetime import datetime
import pandas as pd
import json
import shutil, os
import csv

# Function to create a log file with a dynamic name
def create_log_file(log_file_path, filename_prefix):
    file_path = log_file_path + filename_prefix + f"_log-{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    with open(file_path, 'w') as file:
        file.write("Log file created at: " + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + '\n')
    return file_path

# Function to save data list into csv file
def to_csv(data,landing_folder,file_name,add_timestamp_suffix=True):
    if isinstance(data, list):
        df = pd.DataFrame(data)
    elif isinstance(data, pd.DataFrame):
        df = data    
    if(add_timestamp_suffix==True):
        # Create a filename with the timestamp
        current_timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        # Create a filename with the timestamp
        file_name = f"{file_name}-{current_timestamp}.csv"
    else:
        file_name = f"{file_name}.csv"

    file_path = landing_folder + file_name
    df.to_csv(file_path, index=False,quoting=csv.QUOTE_ALL,encoding='utf-8')
    return file_name

# Function to save raw json data into file
def to_json(data,landing_folder,file_name,add_timestamp_suffix=True):
    if(add_timestamp_suffix==True):
        # Create a filename with the timestamp
        current_timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        # Create a filename with the timestamp
        file_name = f"{file_name}-{current_timestamp}.json"
    else:
        file_name = f"{file_name}.json"

    file_path = landing_folder + file_name

    # Write dictionary to file
    with open(file_path, "w") as file:
        json.dump(data, file)    
    return file_name

# Function to save raw json data into file
def to_xml(data,landing_folder,file_name,columns_to_keep=None):
    # if(add_timestamp_suffix==True):
    #     # Create a filename with the timestamp
    #     #current_timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    #     # Create a filename with the timestamp
    #     file_name = f"{file_name}-{current_timestamp}.xml"
    # else:
    #     file_name = f"{file_name}.xml"

    file_path = landing_folder + file_name

    df = pd.DataFrame(data)
    
    if columns_to_keep:
        df = df[columns_to_keep]
    
    # Convert DataFrame to XML
    xml_string = df.to_xml()

    # Write XML string to a file
    with open(file_path, 'w') as f:
        f.write(xml_string)
        
def to_log(log_file_path, logging_level,msg): #logging_level = exception, debug, info, warning, error,critical
    # START - Logging configuration
    logging.basicConfig(
        filename=log_file_path,
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s]: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )
    # END - Logging configuration
    if logging_level=='exception':
        logging.exception(msg)
    if logging_level=='info':
        logging.info(msg)
    if logging_level=='warning':
        logging.warning(msg)
    if logging_level=='error':
        logging.error(msg)
    if logging_level=='critical':
        logging.critical(msg)
    if logging_level=='debug':
        logging.debug(msg)

def convert_1d_to_2d_list(single_row_list, elements_per_row=100):
    two_dimensional_list = []

    for i in range(0, len(single_row_list), elements_per_row):
        row = single_row_list[i:i+elements_per_row]
        two_dimensional_list.append(row)

    return two_dimensional_list

def convert_2d_to_1d_commaseparated_list(two_dimensional_list):
    one_dimensional_list = []

    for row in two_dimensional_list:
        comma_separated_string = ','.join(map(str, row))
        one_dimensional_list.append(comma_separated_string)

    return one_dimensional_list

def move_file(source_file, destination):
    try:
        # Move the file from source to destination
        shutil.move(source_file, destination)
        print(f"File moved successfully from '{source_file}' to '{destination}'")
    except Exception as e:
        print(f"Error moving file: {e}")
        
def move_files(source_folder, destination_folder):
    try:
        # List all files in the source folder
        files = os.listdir(source_folder)
        
        # Move each file to the destination folder
        for file in files:
            source_file = os.path.join(source_folder, file)
            destination_file = os.path.join(destination_folder, file)
            shutil.move(source_file, destination_file)
        
        print(f"All files moved from '{source_folder}' to '{destination_folder}'")
    except Exception as e:
        print(f"Error moving files: {e}")
        
# Function to flatten the nested dictionary
def flatten_dict(d, parent_key='', sep='_'):
    items = []
    for k, v in d.items():
        new_key = parent_key + sep + k if parent_key else k
        if isinstance(v, dict):
            items.extend(flatten_dict(v, new_key, sep=sep).items())
        else:
            items.append((new_key, v))
    return dict(items)

def filter_list_of_dicts_by_attributes(list_of_dicts, attribute_names):
    return [{key: d.get(key, None) for key in attribute_names} for d in list_of_dicts]