"""
Created on Fri Apr 26 13:34:56 2024

@author: carlos.chiarella
"""
import pandas as pd
from datetime import datetime
import ShopifyData, Helper

def get_disputes(access_token
                 ,api_base_url
                 ,params
                 ,landing_path
                 ,save_raw=False
                 ,raw_file_path=''
                 ,log_file_path=''):
    
    files=[]

    new_api_base_url = api_base_url + r'shopify_payments/' 
    disputeDetailList = ShopifyData.get_data(access_token,new_api_base_url,'disputes',params,log_file_path)
               
    if save_raw == True:
        files.append(Helper.to_json(disputeDetailList, raw_file_path,'disputes',True))
      
    #1.0 disputes
    files.append(Helper.to_csv(disputeDetailList,landing_path,'disputes'))

    # dispute evidence
    #dispute_evidence_List = []
    #for item in disputeDetailList:
    #         disputeid = item['id']  
    #         new_api_base_url_new = new_api_base_url + r'disputes/' + str(disputeid) + r'/'
    #         itm_list = ShopifyData.get_data(access_token,new_api_base_url_new,'dispute_evidences',params,log_file_path)
    #         dispute_evidence_List.extend(itm_list)
     
    #files.append(Helper.to_csv(dispute_evidence_List,landing_path,'dispute_evidence'))

    #build header info
    file_info={}
    file_info['files'] = files
    #file_info['dispute_evidences_record_count']= len(dispute_evidence_List)
    file_info['incremental_load_record_count']= len(disputeDetailList)
    return file_info

def get_payouts(access_token
                 ,api_base_url
                 ,params
                 ,landing_path
                 ,save_raw=False
                 ,raw_file_path=''
                 ,log_file_path=''):
    
    files=[]

    new_api_base_url = api_base_url + r'shopify_payments/' 

    payoutDetailList = ShopifyData.get_data(access_token,new_api_base_url,'payouts',params,log_file_path)

    if save_raw == True:
        files.append(Helper.to_json(payoutDetailList, raw_file_path,'payouts',True))
      
    #1.0 payouts
    payoutList = [{k: v for (k,v) in l.items() if not isinstance(v,dict) and not isinstance(v,list)} for l in payoutDetailList]
    files.append(Helper.to_csv(payoutList,landing_path,'payouts'))

    #1.1 summary
    payout_summary_list = [
                        {'parent_id': item['id'], **item['summary']}
                               for item in payoutDetailList
                           ]
    files.append(Helper.to_csv(payout_summary_list,landing_path,'payout_summary_list'))

    #1.2 transactions
    transaction_List = []
    for item in payoutDetailList:
             payoutid = item['id']  
             #api_base_url_new = new_api_base_url + r'balance/' + str(payoutid) + r'/'
             api_base_url_new = new_api_base_url + r'balance/'
             params['payout_id'] = str(payoutid)
             itm_list = ShopifyData.get_data(access_token,api_base_url_new,'transactions',params,log_file_path)
             transaction_List.extend(itm_list)
    
    transactionDetailList = ShopifyData.get_data(access_token,api_base_url_new,'transactions',params,log_file_path)
     
    files.append(Helper.to_csv(transactionDetailList,landing_path,'transactions'))
    
    #build header info
    file_info={}
    file_info['files'] = files
    file_info['payout_summary_list_record_count'] = len(payout_summary_list)
    file_info['transaction_record_count'] = len(transactionDetailList)
    file_info['incremental_load_record_count']= len(payoutList)

    return file_info