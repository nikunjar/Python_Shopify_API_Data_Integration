"""
Created on Fri Apr 26 13:34:56 2024

@author: carlos.chiarella
"""
import pandas as pd
from datetime import datetime
import ShopifyData, Helper

def get_tender_transactions(access_token
                 ,api_base_url
                 ,params
                 ,landing_path
                 ,save_raw=False
                 ,raw_file_path=''
                 ,log_file_path=''):
    
    files=[]

    tendertranDetailList = ShopifyData.get_data(access_token,api_base_url,'tender_transactions',params,log_file_path)
               
    if save_raw == True:
        files.append(Helper.to_json(tendertranDetailList, raw_file_path,'tender_transactions',True))
    
    files.append(Helper.to_csv(tendertranDetailList,landing_path,'tender_transactions'))
    #build header info
    file_info={}
    file_info['files'] = files
    file_info['incremental_load_record_count']= len(tendertranDetailList)
    return file_info