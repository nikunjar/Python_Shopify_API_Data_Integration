"""
Created on Fri Apr 26 13:34:56 2024

@author: carlos.chiarella
"""
import pandas as pd
from datetime import datetime
import ShopifyData, Helper

def get_price_rules(access_token
                 ,api_base_url
                 ,params
                 ,landing_path
                 ,save_raw=False
                 ,raw_file_path=''
                 ,log_file_path=''):

        files=[]
        discountDetailList = ShopifyData.get_data(access_token,api_base_url,'price_rules',params,log_file_path)
        attribute_names = ['id', 'value_type', 'value', 'customer_selection', 'target_type', 'target_selection', 'allocation_method', 'allocation_limit', 'once_per_customer',
             'usage_limit', 'starts_at', 'ends_at', 'created_at', 'updated_at', 'entitled_product_ids', 'entitled_variant_ids', 'entitled_collection_ids',
             'entitled_country_ids', 'prerequisite_product_ids', 'prerequisite_variant_ids', 'prerequisite_collection_ids', 'customer_segment_prerequisite_ids', 
             'prerequisite_customer_ids', 'prerequisite_subtotal_range', 'prerequisite_quantity_range', 'prerequisite_shipping_price_range', 
             'prerequisite_to_entitlement_quantity_ratio', 'prerequisite_to_entitlement_purchase', 'title', 'admin_graphql_api_id']
        discountDetailList = Helper.filter_list_of_dicts_by_attributes(discountDetailList, attribute_names)


        if save_raw == True:
                files.append(Helper.to_json(discountDetailList, raw_file_path,'price_rules',True))

        #1.0
        if len(discountDetailList)>0:
                files.append(Helper.to_csv(discountDetailList,landing_path,'price_rules'))

        #2.0
        new_api_base_url = api_base_url
        discount_codes_list = []
        for entry in discountDetailList:
                new_api_base_url = api_base_url + r'price_rules/' + str(entry['id']) + r'/'
                discount_codes_list.extend(ShopifyData.get_data(access_token,new_api_base_url,'discount_codes',params,log_file_path))
                
        attribute_names = ['id', 'price_rule_id', 'code', 'usage_count', 'created_at', 'updated_at']
        discount_codes_list = Helper.filter_list_of_dicts_by_attributes(discount_codes_list, attribute_names)

        if len(discount_codes_list)>0:
                files.append(Helper.to_csv(discount_codes_list,landing_path,'discount_codes'))

        #build header info
        file_info={}
        file_info['files'] = files
        file_info['incremental_load_record_count']= len(discountDetailList)
        return file_info