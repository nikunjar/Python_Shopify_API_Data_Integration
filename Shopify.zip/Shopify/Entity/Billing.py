# -*- coding: utf-8 -*-
"""
Created on Fri Apr 26 13:34:56 2024

@author: carlos.chiarella
"""

import pandas as pd
from datetime import datetime
import ShopifyData, Helper

def get_application_charges(access_token
                 ,api_base_url
                 ,params
                 ,landing_path
                 ,save_raw=False
                 ,raw_file_path=''
                 ,log_file_path=''):
    
    files=[]
    
    applicationchargeDetailList = ShopifyData.get_data(access_token,api_base_url,'application_charges',params,log_file_path)
 
    if save_raw == True:
            files.append(Helper.to_json(applicationchargeDetailList, raw_file_path,'application_charges',True))
    
    #1.0 application_charges
    files.append(Helper.to_csv(applicationchargeDetailList,landing_path,'application_charges'))

    #build header info
    file_info={}
    file_info['files'] = files
    file_info['incremental_load_record_count'] = len(applicationchargeDetailList)
    return file_info
    
def get_application_credits(access_token
                 ,api_base_url
                 ,params
                 ,landing_path
                 ,save_raw=False
                 ,raw_file_path=''
                 ,log_file_path=''):
    
    files=[]
    
    applicationcreditDetailList = ShopifyData.get_data(access_token,api_base_url,'application_credits',params,log_file_path)
        
    if save_raw == True:
            files.append(Helper.to_json(applicationcreditDetailList, raw_file_path,'application_credits',True))
            
    #1.0 application_charges
    files.append(Helper.to_csv(applicationcreditDetailList,landing_path,'application_credits'))

    #build header info
    file_info={}
    file_info['files'] = files
    file_info['incremental_load_record_count'] = len(applicationcreditDetailList)
    return file_info

def get_recurring_application_charges(access_token
                 ,api_base_url
                 ,params
                 ,landing_path
                 ,save_raw=False
                 ,raw_file_path=''
                 ,log_file_path=''):
    files=[]
    
    recurringapplicationchargeDetailList = ShopifyData.get_data(access_token,api_base_url,'recurring_application_charges',params,log_file_path)
    
    if save_raw == True:
            files.append(Helper.to_json(recurringapplicationchargeDetailList, raw_file_path,'recurring_application_charges',True))
            
    #1.0 application_charges
    files.append(Helper.to_csv(recurringapplicationchargeDetailList,landing_path,'recurring_application_charges'))
    usage_charges_List = []
    for item in recurringapplicationchargeDetailList:
             recapplchargeid = item['id']  
             api_base_url_new = api_base_url + r'recurring_application_charges/' + recapplchargeid + r'/'
             itm_list = ShopifyData.get_data(access_token,api_base_url_new,'usage_charges',params,log_file_path)
             usage_charges_List.extend(itm_list)
     
    files.append(Helper.to_csv(usage_charges_List,landing_path,'usage_charges'))
     
    #build header info
    file_info={}
    file_info['files'] = files
    file_info['application_charges_record_count'] = len(usage_charges_List)
    file_info['incremental_load_record_count'] = len(recurringapplicationchargeDetailList)
    
    
    return file_info

