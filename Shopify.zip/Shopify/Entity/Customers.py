# -*- coding: utf-8 -*-
"""
Created on Tue Apr 16 09:57:06 2024

@author: carlos.chiarella
"""

import pandas as pd
from datetime import datetime
import ShopifyData, Helper

def get_customers(access_token
                 ,api_base_url
                 ,params
                 ,landing_path
                 ,save_raw=False
                 ,raw_file_path=''
                 ,log_file_path=''):
    
        files=[]
        
        custDetailList = ShopifyData.get_data(access_token,api_base_url,'customers',params,log_file_path)
               
        if save_raw == True:
                files.append(Helper.to_json(custDetailList, raw_file_path,'customers',True))
      
        #1.0 customers 
        attribute_names = ['id','email','created_at','updated_at','first_name','last_name','orders_count'
                        ,'state','total_spent','last_order_id','note','verified_email','multipass_identifier'
                        ,'tax_exempt','tags','last_order_name','currency','phone','accepts_marketing'
                        ,'accepts_marketing_updated_at','sms_marketing_consent','marketing_opt_in_level'
                        ,'admin_graphql_api_id']
        custList = Helper.filter_list_of_dicts_by_attributes(custDetailList, attribute_names)
        #custList = [{k: v for (k,v) in l.items() if not isinstance(v,dict) and not isinstance(v,list)} for l in custDetailList]
        if len(custList)>0:
               files.append(Helper.to_csv(custList,landing_path,'customers'))

        #1.1 email_marketing_consent tables
        email_marketing_consent_list = [
                               {'customer_id': item['id'], **item['email_marketing_consent']}
                               for item in custDetailList
                               if item.get('email_marketing_consent') 
                           ]
        #Excluding children tables
        attribute_names = ['customer_id','state','opt_in_level','consent_updated_at']
        customers_email_marketing_consent_list = Helper.filter_list_of_dicts_by_attributes(email_marketing_consent_list, attribute_names)
        #customers_email_marketing_consent_list = [{k: v for (k,v) in l.items() if not isinstance(v,dict) and not isinstance(v,list)} for l in email_marketing_consent_list]
        if len(customers_email_marketing_consent_list)>0:
                files.append(Helper.to_csv(customers_email_marketing_consent_list,landing_path,'customers_email_marketing_consent'))
        
        #1.2 default_address 
        customers_default_address_list = [
                                 item['default_address']
                                 for item in custDetailList if item.get('default_address')
                               ]
        
        attribute_names = ['id', 'customer_id', 'first_name', 'last_name', 'company', 'address1', 'address2', 'city', 'province', 'country', 'zip', 'phone', 
                           'name', 'province_code', 'country_code', 'country_name', 'default']
        customers_default_address_list = Helper.filter_list_of_dicts_by_attributes(customers_default_address_list, attribute_names)
        #Excluding children tables
        if len(customers_default_address_list)>0:
                files.append(Helper.to_csv(customers_default_address_list,landing_path,'customers_default_address'))
        # # checkouts_billing_address_table = pd.DataFrame(checkouts_billing_address_list)
        
        #1.3 addresses
        customers_addresses_list =[ ele
                for entry in custDetailList  # in entry I will get a customer per loop
                for ele in (entry['addresses'] if entry.get('addresses') else [])  #entry['addresses'] is a list, select parent element also
                ]
        
        attribute_names = ['id', 'customer_id', 'first_name', 'last_name', 'company', 'address1', 'address2', 'city', 'province', 'country', 'zip', 'phone', 
                           'name', 'province_code', 'country_code', 'country_name', 'default']
        customers_addresses_list = Helper.filter_list_of_dicts_by_attributes(customers_addresses_list, attribute_names)
        if len(customers_addresses_list)>0:
                files.append(Helper.to_csv(customers_addresses_list,landing_path,'customers_addresses'))
        
        #build header info
        file_info={}
        file_info['files'] = files
        file_info['incremental_load_record_count']= len(custDetailList)
        return file_info
