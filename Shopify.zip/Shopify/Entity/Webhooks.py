"""
Created on Fri Apr 26 13:34:56 2024

@author: carlos.chiarella
"""
import pandas as pd
from datetime import datetime
import ShopifyData, Helper

def get_webhooks(access_token
                 ,api_base_url
                 ,params
                 ,landing_path
                 ,save_raw=False
                 ,raw_file_path=''
                 ,log_file_path=''):
    
    files=[]

    webhookDetailList = ShopifyData.get_data(access_token,api_base_url,'webhooks',params,log_file_path)
               
    if save_raw == True:
        files.append(Helper.to_json(webhookDetailList, raw_file_path,'webhooks',True))
    
    files.append(Helper.to_csv(webhookDetailList,landing_path,'webhooks'))
    #build header info
    file_info={}
    file_info['files'] = files
    file_info['incremental_load_record_count']= len(webhookDetailList)
    return file_info