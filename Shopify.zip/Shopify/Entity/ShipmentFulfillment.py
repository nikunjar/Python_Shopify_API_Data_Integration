"""
Created on Fri Apr 26 13:34:56 2024

@author: carlos.chiarella
"""
import pandas as pd
from datetime import datetime
import ShopifyData, Helper

def get_carrier_services(access_token
                 ,api_base_url
                 ,params
                 ,landing_path
                 ,save_raw=False
                 ,raw_file_path=''
                 ,log_file_path=''):
    
    files=[]

    carrierservDetailList = ShopifyData.get_data(access_token,api_base_url,'carrier_services',params,log_file_path)
               
    if save_raw == True:
        files.append(Helper.to_json(carrierservDetailList, raw_file_path,'carrier_services',True))
      
    #1.0 carrier_services
    files.append(Helper.to_csv(carrierservDetailList,landing_path,'carrier_services'))

    #build header info
    file_info={}
    file_info['files'] = files
    file_info['incremental_load_record_count']= len(carrierservDetailList)
    return file_info

def get_fulfillment_services(access_token
                 ,api_base_url
                 ,params
                 ,landing_path
                 ,save_raw=False
                 ,raw_file_path=''
                 ,log_file_path=''):
    
    files=[]

    fulfillmentservDetailList = ShopifyData.get_data(access_token,api_base_url,'fulfillment_services',params,log_file_path)
               
    if save_raw == True:
        files.append(Helper.to_json(fulfillmentservDetailList, raw_file_path,'fulfillment_services',True))
      
    #1.0 carrier_services
    files.append(Helper.to_csv(fulfillmentservDetailList,landing_path,'fulfillment_services'))

    #build header info
    file_info={}
    file_info['files'] = files
    file_info['incremental_load_record_count']= len(fulfillmentservDetailList)
    return file_info