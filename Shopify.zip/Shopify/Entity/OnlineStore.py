# -*- coding: utf-8 -*-
"""
Created on Tue Apr 16 09:57:06 2024

@author: carlos.chiarella
"""

import pandas as pd
from datetime import datetime
import ShopifyData, Helper

# def get_blogs(access_token
#                  ,api_base_url
#                  ,params
#                  ,landing_path
#                  ,save_raw=False
#                  ,raw_file_path=''
#                  ,log_file_path=''):
    
#     files=[]

#     blogDetailList = ShopifyData.get_data(access_token,api_base_url,'blogs',params,log_file_path)
               
#     if save_raw == True:
#         files.append(Helper.to_json(blogDetailList, raw_file_path,'blogs',True))
      
#     #1.0 blogs
#     files.append(Helper.to_csv(blogDetailList,landing_path,'blogs'))

#     article_List = []

#     for item in blogDetailList:
#              blogid = item['id']  
#              api_base_url_new = api_base_url + r'blogs/' + str(blogid) + r'/'
#              itm_list = ShopifyData.get_data(access_token,api_base_url_new,'articles',params,log_file_path)
#              article_List.extend(itm_list)
     
#     files.append(Helper.to_csv(article_List,landing_path,'articles'))

#     # for comments
#     comment_List = ShopifyData.get_data(access_token,api_base_url,'comments',params,log_file_path)

#     files.append(Helper.to_csv(article_List,landing_path,'comments'))

#     # for authors in articles
#     new_api_base_url = api_base_url + r'articles/' 
#     authors_List = ShopifyData.get_data(access_token,new_api_base_url,'authors',params,log_file_path)

#     files.append(Helper.to_csv(authors_List,landing_path,'authors'))

#     # for tags in articles
#     tags_List = ShopifyData.get_data(access_token,new_api_base_url,'tags',params,log_file_path)

#     files.append(Helper.to_csv(tags_List,landing_path,'tags'))

#     #build header info
#     file_info={}
#     file_info['files'] = files
#     file_info['article_record_count'] = len(article_List)
#     file_info['comment_record_count'] = len(comment_List)
#     file_info['authors_record_count'] = len(authors_List)
#     file_info['tags_record_count'] = len(tags_List)
#     file_info['incremental_load_record_count']= len(blogDetailList)
#     return file_info


def get_pages(access_token
                 ,api_base_url
                 ,params
                 ,landing_path
                 ,save_raw=False
                 ,raw_file_path=''
                 ,log_file_path=''):
    
    files=[]

    pageDetailList = ShopifyData.get_data(access_token,api_base_url,'pages',params,log_file_path)
               
    if save_raw == True:
        files.append(Helper.to_json(pageDetailList, raw_file_path,'pages',True))
      
    #1.0 pages 
    attribute_names = ['id', 'title', 'shop_id', 'handle', 'body_html', 'author', 'created_at', 'updated_at', 'published_at', 'template_suffix', 
         'admin_graphql_api_id']
    pageDetailList = Helper.filter_list_of_dicts_by_attributes(pageDetailList, attribute_names)

    if len(pageDetailList)>0:
        files.append(Helper.to_csv(pageDetailList,landing_path,'pages'))

    #build header info
    file_info={}
    file_info['files'] = files
    file_info['incremental_load_record_count']= len(pageDetailList)
    return file_info

# def get_redirects(access_token
#                  ,api_base_url
#                  ,params
#                  ,landing_path
#                  ,save_raw=False
#                  ,raw_file_path=''
#                  ,log_file_path=''):
    
#     files=[]

#     redirectDetailList = ShopifyData.get_data(access_token,api_base_url,'redirects',params,log_file_path)
               
#     if save_raw == True:
#         files.append(Helper.to_json(redirectDetailList, raw_file_path,'redirects',True))
      
#     #1.0 pages 
#     files.append(Helper.to_csv(redirectDetailList,landing_path,'redirects'))

#     #build header info
#     file_info={}
#     file_info['files'] = files
#     file_info['redirect_record_count'] = len(redirectDetailList)
#     return file_info

# def get_script_tags(access_token
#                  ,api_base_url
#                  ,params
#                  ,landing_path
#                  ,save_raw=False
#                  ,raw_file_path=''
#                  ,log_file_path=''):
    
#     files=[]

#     scripttagDetailList = ShopifyData.get_data(access_token,api_base_url,'script_tags',params,log_file_path)
               
#     if save_raw == True:
#         files.append(Helper.to_json(scripttagDetailList, raw_file_path,'script_tags',True))
      
#     #1.0 pages 
#     files.append(Helper.to_csv(scripttagDetailList,landing_path,'script_tags'))

#     #build header info
#     file_info={}
#     file_info['files'] = files
#     file_info['script_tag_record_count'] = len(scripttagDetailList)
#     return file_info

# def get_themes(access_token
#                  ,api_base_url
#                  ,params
#                  ,landing_path
#                  ,save_raw=False
#                  ,raw_file_path=''
#                  ,log_file_path=''):
    
#     files=[]

#     themeDetailList = ShopifyData.get_data(access_token,api_base_url,'themes',params,log_file_path)
               
#     if save_raw == True:
#         files.append(Helper.to_json(themeDetailList, raw_file_path,'themes',True))
      
#     #1.0 pages 
#     files.append(Helper.to_csv(themeDetailList,landing_path,'themes'))

#     # assets
#     asset_List = []

#     for item in themeDetailList:
#              themeid = item['id']  
#              api_base_url_new = api_base_url + r'themes/' + str(themeid) + r'/'
#              itm_list = ShopifyData.get_data(access_token,api_base_url_new,'assets',params,log_file_path)
#              asset_List.extend(itm_list)
     
#     files.append(Helper.to_csv(asset_List,landing_path,'assets'))

#     #build header info
#     file_info={}
#     file_info['files'] = files
#     file_info['themes_record_count'] = len(themeDetailList)
#     file_info['assets_record_count'] = len(asset_List)
#     return file_info