import pandas as pd
from datetime import datetime
import ShopifyData, Helper

def get_product_listings(access_token
                 ,api_base_url
                 ,params
                 ,landing_path
                 ,save_raw=False
                 ,raw_file_path=''
                 ,log_file_path=''):

        files=[]
        prdDetailList = ShopifyData.get_data(access_token,api_base_url,'product_listings',params,log_file_path)

        if save_raw == True:
                files.append(Helper.to_json(prdDetailList, raw_file_path,'product_listings',True))

        #1.0
        prdList = [{k: v for (k,v) in l.items() if not isinstance(v,dict) and not isinstance(v,list)} for l in prdDetailList]
        if len(prdList)>0:
                files.append(Helper.to_csv(prdList,landing_path,'product_listings'))
        
        #1.1
        variants_list = [ ele 
                        for entry in prdDetailList if entry.get('variants')
                        for ele in entry['variants']  #entry['variants'] is a list, select parent element also
                        ]
        if len(variants_list)>0:
                files.append(Helper.to_csv(variants_list,landing_path,'product_listings_variants'))

        #1.2
        # options_list =  [ ele 
        #                 for entry in prdDetailList if entry.get('options')
        #                 for ele in entry['options']  #entry['variants'] is a list, select parent element also
        #                 ]
        # if len(options_list)>0:
        #         files.append(Helper.to_csv(options_list,landing_path,'product_listings_options'))

        # #1.3
        # images_list =   [ ele 
        #                 for entry in prdDetailList if entry.get('images')
        #                 for ele in entry['images']  #entry['variants'] is a list, select parent element also
        #                 ]
        # if len(images_list)>0:
        #         files.append(Helper.to_csv(images_list,landing_path,'product_listings_images'))

        # image_list =    [ entry['image'] 
        #                 for entry in prdDetailList if entry.get('image') #entry['image'] is a dictionary, select parent element also
        #                 ] 
        # #[{k: v for (k,v) in l.items() if not isinstance(v,dict) and not isinstance(v,list)} for l in [img['image'] for img in prdDetailList]]
        # if len(image_list)>0:
        #         files.append(Helper.to_csv(image_list,landing_path,'product_listings_image'))

        #build header info
        file_info={}
        file_info['files'] = files
        file_info['incremental_load_record_count']= len(prdDetailList)
        return file_info
