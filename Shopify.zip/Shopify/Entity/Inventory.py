import pandas as pd
from datetime import datetime
import ShopifyData, Helper

def get_locations(access_token,api_base_url,params,landing_path,save_raw=False,raw_file_path='',log_file_path=''):
        files=[]
        locationsDetail = ShopifyData.get_data(access_token,api_base_url,'locations',params,log_file_path)
        attribute_names = ['id', 'name', 'address1', 'address2', 'city', 'zip', 'province', 'country', 'phone', 'created_at', 'updated_at', 'country_code', 'country_name', 
            'province_code', 'legacy', 'active', 'admin_graphql_api_id', 'localized_country_name', 'localized_province_name']
        locationsDetail = Helper.filter_list_of_dicts_by_attributes(locationsDetail, attribute_names)

        if save_raw == True:
                files.append(Helper.to_json(locationsDetail, raw_file_path,'locations',True))

        #1.0
        if len(locationsDetail)>0:
                files.append(Helper.to_csv(locationsDetail,landing_path,'locations'))

        #1.1 -- inventory_levels. send comma separated ids from location as parameter
        # location_ids = [loc['id'] for loc in locationsDetail]
        # params_inv_level = params.copy()
        # params_inv_level['location_ids'] = ','.join(map(str,location_ids))
        # inventory_levels_list = ShopifyData.get_data(access_token,api_base_url,'inventory_levels',params_inv_level,log_file_path)
        # if len(inventory_levels_list)>0:
        #         files.append(Helper.to_csv(inventory_levels_list,landing_path,'inventory_levels'))

        #1.1.1 -- inventory_items. send comma separated inventory_items_id from inventory_items as parameter
        # inventory_item_ids = [inv['inventory_item_id'] for inv in inventory_levels_list]
        # comma_separated_inv_itm_ids_list = Helper.convert_2d_to_1d_commaseparated_list(
        #                                         Helper.convert_1d_to_2d_list(inventory_item_ids))
        
        # inventory_items_list = []
        # for inv_itm_ids in comma_separated_inv_itm_ids_list:
        #         params_inv_itm_ids = params.copy()
        #         params_inv_itm_ids['ids'] = inv_itm_ids
        #         itm_list = ShopifyData.get_data(access_token,api_base_url,'inventory_items',params_inv_itm_ids,log_file_path)
        #         inventory_items_list.extend(itm_list)
        
        # if len(inventory_items_list)>0:
        #         files.append(Helper.to_csv(inventory_items_list,landing_path,'inventory_items'))

        #build header info
        file_info={}
        file_info['files'] = files
        file_info['incremental_load_record_count']= len(locationsDetail)
        return file_info
