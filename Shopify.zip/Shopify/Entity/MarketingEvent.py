# -*- coding: utf-8 -*-
"""
Created on Mon May  6 11:13:46 2024

@author: carlos.chiarella
"""

import pandas as pd
from datetime import datetime
import ShopifyData, Helper

def get_marketing_events(access_token
                 ,api_base_url
                 ,params
                 ,landing_path
                 ,save_raw=False
                 ,raw_file_path=''
                 ,log_file_path=''):
    
    files=[]
    
    marketingeventDetailList = ShopifyData.get_data(access_token,api_base_url,'marketing_events',params,log_file_path)
 
    if save_raw == True:
            files.append(Helper.to_json(marketingeventDetailList, raw_file_path,'marketing_events',True))
    
    #1.0 application_charges
    files.append(Helper.to_csv(marketingeventDetailList,landing_path,'marketing_events'))

    #build header info
    file_info={}
    file_info['files'] = files
    file_info['incremental_load_record_count'] = len(marketingeventDetailList)
    return file_info