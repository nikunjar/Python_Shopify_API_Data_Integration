import pandas as pd
from datetime import datetime
import ShopifyData, Helper

def get_products(access_token
                 ,api_base_url
                 ,params
                 ,landing_path
                 ,save_raw=False
                 ,raw_file_path=''
                 ,log_file_path=''):

        files=[]
        prdDetailList = ShopifyData.get_data(access_token,api_base_url,'products',params,log_file_path)

        if save_raw == True:
                files.append(Helper.to_json(prdDetailList, raw_file_path,'products',True))

        #1.0
        attribute_names = ['id', 'title', 'body_html', 'vendor', 'product_type', 'created_at', 'handle', 'updated_at', 
                              'published_at', 'template_suffix', 'published_scope', 'tags', 'status', 'admin_graphql_api_id']
        # prdList = [{k: v for (k,v) in l.items() if not isinstance(v,dict) and not isinstance(v,list)} for l in prdDetailList]
        prdList = Helper.filter_list_of_dicts_by_attributes(prdDetailList, attribute_names)
        if len(prdList)>0:
                files.append(Helper.to_csv(prdList,landing_path,'products'))
        
        #1.1
        variants_list = [ ele 
                        for entry in prdDetailList if entry.get('variants')
                        for ele in entry['variants']  #entry['variants'] is a list, select parent element also
                        ]
        attribute_names = ['id', 'product_id', 'title','price','sku','position','inventory_policy','compare_at_price'
                ,'fulfillment_service','inventory_management','option1','option2','option3','created_at'
                ,'updated_at','taxable','barcode','grams','weight','weight_unit','inventory_item_id'
                ,'inventory_quantity','old_inventory_quantity','tax_code','requires_shipping'
                ,'admin_graphql_api_id','image_id']
        variants_list = Helper.filter_list_of_dicts_by_attributes(variants_list, attribute_names)
        
        if len(variants_list)>0:
                files.append(Helper.to_csv(variants_list,landing_path,'products_variants'))

        #1.2
        # options_list =  [ ele 
        #                 for entry in prdDetailList if entry.get('options')
        #                 for ele in entry['options']  #entry['variants'] is a list, select parent element also
        #                 ]
        # if len(options_list)>0:
        #         files.append(Helper.to_csv(options_list,landing_path,'products_options'))

        # #1.3
        # images_list =   [ ele 
        #                 for entry in prdDetailList if entry.get('images')
        #                 for ele in entry['images']  #entry['variants'] is a list, select parent element also
        #                 ]
        # if len(images_list)>0:
        #         files.append(Helper.to_csv(images_list,landing_path,'products_images'))

        # image_list =    [ entry['image'] 
        #                 for entry in prdDetailList if entry.get('image') #entry['image'] is a dictionary, select parent element also
        #                 ] 
        # #[{k: v for (k,v) in l.items() if not isinstance(v,dict) and not isinstance(v,list)} for l in [img['image'] for img in prdDetailList]]
        # if len(image_list)>0:
        #         files.append(Helper.to_csv(image_list,landing_path,'products_image'))

        #build header info
        file_info={}
        file_info['files'] = files
        file_info['incremental_load_record_count']= len(prdDetailList)
        return file_info

# def get_collects(access_token
#                  ,api_base_url
#                  ,params
#                  ,landing_path
#                  ,save_raw=False
#                  ,raw_file_path=''
#                  ,log_file_path=''):

#         files=[]
#         prdDetailList = ShopifyData.get_data(access_token,api_base_url,'collects',params,log_file_path)

#         if save_raw == True:
                # files.append(Helper.to_json(prdDetailList, raw_file_path,'collects',True))

#         #1.0
#         # prdList = [{k: v for (k,v) in l.items() if not isinstance(v,dict) and not isinstance(v,list)} for l in prdDetailList]
#         if len(prdDetailList)>0:
#                 files.append(Helper.to_csv(prdDetailList,landing_path,'collects'))

#         #build header info
#         file_info={}
#         file_info['files'] = files
#         file_info['incremental_load_record_count']= len(prdDetailList)
#         return file_info

def get_custom_collections(access_token
                 ,api_base_url
                 ,params
                 ,landing_path
                 ,save_raw=False
                 ,raw_file_path=''
                 ,log_file_path=''):

        files=[]
        prdDetailList = ShopifyData.get_data(access_token,api_base_url,'custom_collections',params,log_file_path)

        if save_raw == True:
                files.append(Helper.to_json(prdDetailList, raw_file_path,'custom_collections',True))

        #1.0
        # prdList = [{k: v for (k,v) in l.items() if not isinstance(v,dict) and not isinstance(v,list)} for l in prdDetailList]
        attribute_names = ['id', 'handle', 'title', 'updated_at', 'body_html', 'published_at', 'sort_order', 'template_suffix', 'published_scope', 
                           'admin_graphql_api_id', 'image']
        prdDetailList = Helper.filter_list_of_dicts_by_attributes(prdDetailList, attribute_names)

        if len(prdDetailList)>0:
                files.append(Helper.to_csv(prdDetailList,landing_path,'custom_collections'))

        #build header info
        file_info={}
        file_info['files'] = files
        file_info['incremental_load_record_count']= len(prdDetailList)
        return file_info

# def get_smart_collections(access_token
#                  ,api_base_url
#                  ,params
#                  ,landing_path
#                  ,save_raw=False
#                  ,raw_file_path=''
#                  ,log_file_path=''):

#         files=[]
#         prdDetailList = ShopifyData.get_data(access_token,api_base_url,'smart_collections',params,log_file_path)

#         if save_raw == True:
#                files.append(Helper.to_json(prdDetailList, raw_file_path,'smart_collections',True))

#         #1.0
#         prdList = [{k: v for (k,v) in item.items() if not isinstance(v,dict) and not isinstance(v,list)}
#                    for item in prdDetailList]
#         if len(prdDetailList)>0:
#                 files.append(Helper.to_csv(prdDetailList,landing_path,'smart_collections'))

#         #1.1
#         smart_collections_image_list =    [ {'parent_id':entry['id'], **entry['image']} 
#                         for entry in prdDetailList if entry.get('image') #entry['image'] is a dictionary, select parent element also
#                         ] 
#         if len(smart_collections_image_list)>0:
#                 files.append(Helper.to_csv(smart_collections_image_list,landing_path,'smart_collections_image'))

#         #1.2
#         smart_collections_rules_list = [ {'parent_id':entry['id'], **ele }
#                         for entry in prdDetailList if entry.get('rules')
#                         for ele in entry['rules']  #entry['rules'] is a list, select parent element also
#                         ]
#         if len(smart_collections_rules_list)>0:
#                 files.append(Helper.to_csv(smart_collections_rules_list,landing_path,'smart_collections_rules'))

#         #build header info
#         file_info={}
#         file_info['files'] = files
#         file_info['incremental_load_record_count']= len(prdDetailList)
#         return file_info

