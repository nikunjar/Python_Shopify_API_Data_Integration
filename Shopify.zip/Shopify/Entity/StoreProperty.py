"""
Created on Fri Apr 26 13:34:56 2024

@author: carlos.chiarella
"""
import pandas as pd
from datetime import datetime
import ShopifyData, Helper

def get_countries(access_token
                 ,api_base_url
                 ,params
                 ,landing_path
                 ,save_raw=False
                 ,raw_file_path=''
                 ,log_file_path=''):
    
    files=[]

    countryDetailList = ShopifyData.get_data(access_token,api_base_url,'countries',params,log_file_path)
               
    if save_raw == True:
        files.append(Helper.to_json(countryDetailList, raw_file_path,'countries',True))
      
    #1.0 countries
    countryList = [{k: v for (k,v) in l.items() if not isinstance(v,dict) and not isinstance(v,list)} for l in countryDetailList]
    files.append(Helper.to_csv(countryList,landing_path,'countries'))

    #1.1 provinces
    #province_list = [
    #                    {'parent_id': item['id'], **item['provinces']}
    #                           for item in countryDetailList
    #                       ]
    #1.2 default_address 
    #province_list = [
    #                             item['provinces']
    #                             for item in countryDetailList if item.get('provinces')
    #                            
    #                           ]

    province_list =[ ele
                for entry in countryDetailList  # in entry I will get a customer per loop
                for ele in entry['provinces'] if entry.get('provinces')   
                ]    
    #Excluding children tables
    #    files.append(Helper.to_csv(customers_default_address_list,landing_path,'customers_default_address'))
    files.append(Helper.to_csv(province_list,landing_path,'country_provinces_list'))

    #build header info
    file_info={}
    file_info['files'] = files
    file_info['provice_record_count'] = len(province_list)
    file_info['incremental_load_record_count']= len(countryList)
    return file_info

def get_currencies(access_token
                 ,api_base_url
                 ,params
                 ,landing_path
                 ,save_raw=False
                 ,raw_file_path=''
                 ,log_file_path=''):
    
    files=[]

    currencyDetailList = ShopifyData.get_data(access_token,api_base_url,'currencies',params,log_file_path)
               
    if save_raw == True:
        files.append(Helper.to_json(currencyDetailList, raw_file_path,'currencies',True))
    
    files.append(Helper.to_csv(currencyDetailList,landing_path,'currencies'))
    #build header info
    file_info={}
    file_info['files'] = files
    file_info['incremental_load_record_count']= len(currencyDetailList)
    return file_info

def get_policies(access_token
                 ,api_base_url
                 ,params
                 ,landing_path
                 ,save_raw=False
                 ,raw_file_path=''
                 ,log_file_path=''):
    
    files=[]

    policyDetailList = ShopifyData.get_data(access_token,api_base_url,'policies',params,log_file_path)
               
    if save_raw == True:
        files.append(Helper.to_json(policyDetailList, raw_file_path,'policies',True))
    
    files.append(Helper.to_csv(policyDetailList,landing_path,'policies'))
    #build header info
    file_info={}
    file_info['files'] = files
    file_info['incremental_load_record_count']= len(policyDetailList)
    return file_info

def get_shipping_zones(access_token
                 ,api_base_url
                 ,params
                 ,landing_path
                 ,save_raw=False
                 ,raw_file_path=''
                 ,log_file_path=''):
    
    files=[]

    shippingzoneDetailList = ShopifyData.get_data(access_token,api_base_url,'shipping_zones',params,log_file_path)
               
    if save_raw == True:
        files.append(Helper.to_json(shippingzoneDetailList, raw_file_path,'shipping_zones',True))

    attribute_names = ['id', 'name', 'profile_id', 'location_group_id', 'admin_graphql_api_id']
    shippingzoneList = Helper.filter_list_of_dicts_by_attributes(shippingzoneDetailList, attribute_names)
    #shippingzoneList = [{k: v for (k,v) in l.items() if not isinstance(v,dict) and not isinstance(v,list)} for l in shippingzoneDetailList]    
    
    if len(shippingzoneList)>0:
        files.append(Helper.to_csv(shippingzoneList,landing_path,'shipping_zones'))

    #1.1 countries
    # countrydetailList = [ ele
    #                for l in shippingzoneDetailList if l.get('countries')
    #                 for ele in l['countries']]
    
    # countryList = [{k: v for (k,v) in l.items() if not isinstance(v,dict) and not isinstance(v,list)} 
    #                for l in countrydetailList]
    
    # if len(countryList)>0:
    #     files.append(Helper.to_csv(countryList,landing_path,'shipping_zone_countries'))

    #1.1.1 provinces
    # provinceList = [ ele
    #                for l in countrydetailList if l.get('provinces')
    #                 for ele in l['provinces']]
    
    # if len(provinceList)>0:
    #     files.append(Helper.to_csv(provinceList,landing_path,'shipping_zone_countries_provinces'))

    #1.2 weight_based_shipping_rates
    # weightbasedshippingratedetailList = [ ele
    #                for l in shippingzoneDetailList if l.get('weight_based_shipping_rates')
    #                 for ele in l['weight_based_shipping_rates']]
    
    # if len(weightbasedshippingratedetailList)>0:
    #     files.append(Helper.to_csv(weightbasedshippingratedetailList,landing_path,'weight_based_shipping_rates'))

    #1.3 price_based_shipping_rates
    pricebasedshippingratedetailList = [ ele
                   for l in shippingzoneDetailList if l.get('price_based_shipping_rates')
                    for ele in l['price_based_shipping_rates']]
    
    attribute_names= ['id', 'name', 'price', 'shipping_zone_id', 'min_order_subtotal', 'max_order_subtotal']
    pricebasedshippingratedetailList = Helper.filter_list_of_dicts_by_attributes(pricebasedshippingratedetailList, attribute_names)
    if len(pricebasedshippingratedetailList)>0:
        files.append(Helper.to_csv(pricebasedshippingratedetailList,landing_path,'price_based_shipping_rates'))

    #1.4carrier_shipping_rate_providers
    # carriershippingrateproviderdetailList = [ ele
    #                for l in shippingzoneDetailList if l.get('carrier_shipping_rate_providers')
    #                 for ele in l['carrier_shipping_rate_providers']]
    
    # if len(carriershippingrateproviderdetailList)>0:
    #     files.append(Helper.to_csv(carriershippingrateproviderdetailList,landing_path,'carrier_shipping_rate_providers'))
    
    #build header info
    file_info={}
    file_info['files'] = files
    file_info['price_based_shipping_rates_record_count'] = len(pricebasedshippingratedetailList)
    file_info['incremental_load_record_count']= len(shippingzoneDetailList)
    return file_info
