# -*- coding: utf-8 -*-
"""
Created on Mon May  6 10:51:31 2024

@author: carlos.chiarella
"""

import pandas as pd
from datetime import datetime
import ShopifyData, Helper

def get_events(access_token
                 ,api_base_url
                 ,params
                 ,landing_path
                 ,save_raw=False
                 ,raw_file_path=''
                 ,log_file_path=''):
    
    files=[]
    
    eventsDetailList = ShopifyData.get_data(access_token,api_base_url,'events',params,log_file_path)
 
    if save_raw == True:
            files.append(Helper.to_json(eventsDetailList, raw_file_path,'events',True))
    
    #1.0 application_charges
    files.append(Helper.to_csv(eventsDetailList,landing_path,'events'))

    #build header info
    file_info={}
    file_info['files'] = files
    file_info['incremental_load_record_count'] = len(eventsDetailList)
    return file_info