import pandas as pd
from datetime import datetime
import ShopifyData, Helper
import time

def get_orders(access_token,api_base_url,params,landing_path,save_raw=False,raw_file_path='',log_file_path=''):
        files=[]
        ordDict = ShopifyData.get_data(access_token,api_base_url,'orders',params,log_file_path)

        if save_raw == True:
                files.append(Helper.to_json(ordDict, raw_file_path,'orders',True))

        attribute_names = ['id', 'admin_graphql_api_id', 'app_id', 'browser_ip', 'buyer_accepts_marketing', 'cancel_reason', 'cancelled_at', 
                              'cart_token', 'checkout_id', 'checkout_token', 'closed_at', 'company', 'confirmation_number', 'confirmed', 
                              'contact_email', 'created_at', 'currency', 'current_subtotal_price', 'current_total_additional_fees_set', 
                              'current_total_discounts', 'current_total_duties_set', 'current_total_price', 'current_total_tax', 'customer_locale', 
                              'device_id', 'email', 'estimated_taxes', 'financial_status', 'fulfillment_status', 'landing_site', 'landing_site_ref', 
                              'location_id', 'merchant_of_record_app_id', 'name', 'note', 'number', 'order_number', 'order_status_url', 
                              'original_total_additional_fees_set', 'original_total_duties_set', 'phone', 'po_number', 'presentment_currency', 
                              'processed_at', 'reference', 'referring_site', 'source_identifier', 'source_name', 'source_url', 'subtotal_price', 
                              'tags', 'tax_exempt', 'taxes_included', 'test', 'token', 'total_discounts', 'total_line_items_price', 'total_outstanding', 
                              'total_price', 'total_tax', 'total_tip_received', 'total_weight', 'updated_at', 'user_id', 'payment_terms', 'shipping_address', 
                              'client_details', 'billing_address']
        ordList = Helper.filter_list_of_dicts_by_attributes(ordDict, attribute_names)
        #ordList = [{k: v for (k,v) in l.items() if not isinstance(v,dict) and not isinstance(v,list)} for l in ordDict]
        if len(ordList)>0:
                files.append(Helper.to_csv(ordList,landing_path,'orders'))

        # orders_client_details
        client_details_list =[{'order_id': entry['id'], **(entry['client_details'])} 
                              for entry in ordDict if entry.get('client_details')
                              ]
        attribute_names = ['order_id', 'accept_language', 'browser_height', 'browser_ip', 'browser_width', 'session_hash', 'user_agent']
        client_details_list = Helper.filter_list_of_dicts_by_attributes(client_details_list, attribute_names)

        if len(client_details_list)>0:
                files.append(Helper.to_csv(client_details_list,landing_path,'orders_client_details'))

        # orders_tax_lines_list =[Helper.flatten_dict({"order_id": entry['id'], **ele})
        #                         for entry in ordDict if entry.get('tax_lines')
        #                         for ele in entry['tax_lines']
        #                         ]
        # if len(orders_tax_lines_list)>0:
        #         files.append(Helper.to_csv(orders_tax_lines_list,landing_path,'orders_tax_lines'))
        
        # orders_billing_address
        orders_billing_address_list = [ {"order_id":entry['id'], **entry['billing_address']} 
                               for entry in ordDict if entry.get('billing_address')
                              ]
        
        attribute_names = ['order_id', 'first_name', 'address1', 'phone', 'city', 'zip', 'province', 'country', 'last_name', 'address2', 'company', 'latitude', 
                           'longitude', 'name', 'country_code', 'province_code']
        orders_billing_address_list = Helper.filter_list_of_dicts_by_attributes(orders_billing_address_list, attribute_names)
        if len(orders_billing_address_list)>0:
                files.append(Helper.to_csv(orders_billing_address_list,landing_path,'orders_billing_address'))
        
        # orders_shipping_address
        orders_shipping_address_list = [ {"order_id":entry['id'], **entry['shipping_address']} 
                               for entry in ordDict if entry.get('shipping_address')
                              ]
        attribute_names = ['order_id', 'first_name', 'address1', 'phone', 'city', 'zip', 'province', 'country', 'last_name', 'address2', 'company', 'latitude', 
                           'longitude', 'name', 'country_code', 'province_code']
        orders_shipping_address_list = Helper.filter_list_of_dicts_by_attributes(orders_shipping_address_list, attribute_names)
        if len(orders_shipping_address_list)>0:
                files.append(Helper.to_csv(orders_shipping_address_list,landing_path,'orders_shipping_address'))

        # orders_customer
        orders_customer_list = [Helper.flatten_dict( {"order_id":entry['id'], **entry['customer']} )
                               for entry in ordDict  if entry.get('customer')
                              ]
        attribute_names = ['order_id', 'id', 'email', 'created_at', 'updated_at', 'first_name', 'last_name', 'state', 'note', 'verified_email', 'multipass_identifier',
                           'tax_exempt', 'phone', 'email_marketing_consent_state', 'email_marketing_consent_opt_in_level', 'email_marketing_consent_consent_updated_at',
                           'sms_marketing_consent', 'tags', 'currency', 'accepts_marketing', 'accepts_marketing_updated_at', 'marketing_opt_in_level', 'tax_exemptions',
                           'admin_graphql_api_id', 'default_address_id', 'default_address_customer_id', 'default_address_first_name', 'default_address_last_name', 
                           'default_address_company', 'default_address_address1', 'default_address_address2', 'default_address_city', 'default_address_province',
                           'default_address_country', 'default_address_zip', 'default_address_phone', 'default_address_name', 'default_address_province_code', 
                           'default_address_country_code', 'default_address_country_name', 'default_address_default', 'sms_marketing_consent_state', 
                           'sms_marketing_consent_opt_in_level', 'sms_marketing_consent_consent_updated_at', 'sms_marketing_consent_consent_collected_from']
        orders_customer_list = Helper.filter_list_of_dicts_by_attributes(orders_customer_list, attribute_names)
        if len(orders_customer_list)>0:
                files.append(Helper.to_csv(orders_customer_list,landing_path,'orders_customer'))

        # orders_discount_codes
        orders_discount_codes_detail_list = [Helper.flatten_dict({"order_id": entry['id'], **ele})
                                for entry in ordDict  if entry.get('discount_codes')
                                for ele in entry['discount_codes']
                                ]
        attribute_names = ['order_id','code','amount','type']
        orders_discount_codes_list = Helper.filter_list_of_dicts_by_attributes(orders_discount_codes_detail_list, attribute_names)
        if len(orders_discount_codes_list)>0:
                files.append(Helper.to_csv(orders_discount_codes_list,landing_path,'orders_discount_codes'))


        # orders_line_items
        orders_line_items_detail_list = [Helper.flatten_dict({"order_id": entry['id'], **ele})
                                for entry in ordDict  if entry.get('line_items')
                                for ele in entry['line_items']
                                ]
        attribute_names = ['order_id', 'id', 'admin_graphql_api_id', 'fulfillable_quantity', 'fulfillment_service', 'fulfillment_status', 'gift_card', 'grams', 
                              'name', 'pre_tax_price', 'pre_tax_price_set_shop_money_amount', 'pre_tax_price_set_shop_money_currency_code', 
                              'pre_tax_price_set_presentment_money_amount', 'pre_tax_price_set_presentment_money_currency_code', 'price', 
                              'price_set_shop_money_amount', 'price_set_shop_money_currency_code', 'price_set_presentment_money_amount', 
                              'price_set_presentment_money_currency_code', 'product_exists', 'product_id', 'quantity', 'requires_shipping', 'sku', 
                              'tax_code', 'taxable', 'title', 'total_discount', 'total_discount_set_shop_money_amount', 'total_discount_set_shop_money_currency_code', 
                              'total_discount_set_presentment_money_amount', 'total_discount_set_presentment_money_currency_code', 'variant_id', 
                              'variant_inventory_management', 'variant_title', 'vendor']
        orders_line_items_list = Helper.filter_list_of_dicts_by_attributes(orders_line_items_detail_list, attribute_names)
        #orders_line_items_list = [{k: v for (k,v) in l.items() if not isinstance(v,dict) and not isinstance(v,list)} for l in orders_line_items_detail_list]
        if len(orders_line_items_list)>0:
                files.append(Helper.to_csv(orders_line_items_list,landing_path,'orders_line_items'))

        # orders_line_items_discount_allocations
        orders_line_items_discount_allocations_detail_list = [Helper.flatten_dict({"order_id": entry['order_id'],"line_item_id": entry['id'], **ele})
                                for entry in orders_line_items_detail_list  if entry.get('discount_allocations')
                                for ele in entry['discount_allocations']
                                ]
        attribute_names = ['order_id', 'line_item_id','amount','amount_set_shop_money_amount','amount_set_shop_money_currency_code',
                           'amount_set_presentment_money_amount','amount_set_presentment_money_currency_code',
                           'discount_application_index']
        orders_line_items_discount_allocations_list = Helper.filter_list_of_dicts_by_attributes(orders_line_items_discount_allocations_detail_list, attribute_names)
        if len(orders_line_items_discount_allocations_list)>0:
                files.append(Helper.to_csv(orders_line_items_discount_allocations_list,landing_path,'orders_line_items_discount_allocations'))

     #orders_refunds
        orders_refunds_detail_list = [ele
                                        for entry in ordDict  if entry.get('refunds')
                                        for ele in entry['refunds']
                                     ]
        attribute_names = ['id', 'order_id', 'created_at', 'note', 'processed_at', 'restock', 
                              'total_duties_set', 'user_id', 'order_adjustments', 'duties']
        orders_refunds_list = Helper.filter_list_of_dicts_by_attributes(orders_refunds_detail_list, attribute_names)
        if len(orders_refunds_list)>0:
                files.append(Helper.to_csv(orders_refunds_list,landing_path,'orders_refunds'))

        #orders_refunds_transactions
        orders_refunds_transactions_detail_list = [Helper.flatten_dict({"refund_id":entry['id'], **ele})
                                for entry in orders_refunds_detail_list  if entry.get('transactions')
                                for ele in entry['transactions']
                                ]
        attribute_names = ['id','order_id', 'refund_id', 'amount','authorization','created_at', 'currency', 'device_id', 'error_code', 
                              'gateway', 'kind', 'location_id', 'message','parent_id','payment_id','payments_refund_attributes_status',
                              'payments_refund_attributes_acquirer_reference_number','processed_at','receipt_id','receipt_amount',
                              'receipt_object','receipt_reason','receipt_status','receipt_created','receipt_currency','source_name','status','test',
                              'user_id']
        orders_refunds_transactions_list = Helper.filter_list_of_dicts_by_attributes(orders_refunds_transactions_detail_list, attribute_names)
        if len(orders_refunds_transactions_list)>0:
                files.append(Helper.to_csv(orders_refunds_transactions_list,landing_path,'orders_refunds_transactions'))

        #orders_refunds_line_items
        orders_refunds_line_items_detail_list = [Helper.flatten_dict({"order_id":entry['order_id'],"refund_id":entry['id'], **ele})
                                for entry in orders_refunds_detail_list  if entry.get('refund_line_items')
                                for ele in entry['refund_line_items']
                                ]
        attribute_names = ['id','order_id','refund_id', 'line_item_id','location_id','quantity','restock_type','subtotal', 
                           'subtotal_set_shop_money_amount','subtotal_set_shop_money_currency_code','subtotal_set_presentment_money_amount',
                           'subtotal_set_presentment_money_currency_code','total_tax','total_tax_set_shop_money_amount','total_tax_set_shop_money_currency_code',
                           'total_tax_set_presentment_money_amount','total_tax_set_presentment_money_currency_code']
        orders_refunds_line_items_list = Helper.filter_list_of_dicts_by_attributes(orders_refunds_line_items_detail_list, attribute_names)
        if len(orders_refunds_line_items_list)>0:
                files.append(Helper.to_csv(orders_refunds_line_items_list,landing_path,'orders_refunds_line_items'))

        
        # orders_line_items_tax_lines_list = [ Helper.flatten_dict({"order_id": entry['order_id'],"line_item_id": entry['id'], **ele} )
        #                                 for entry in orders_line_items_detail_list  if entry.get('tax_lines')
        #                                 for ele in entry['tax_lines']
        #                                 ]
        # if len(orders_line_items_tax_lines_list)>0:
        #         files.append(Helper.to_csv(orders_line_items_tax_lines_list,landing_path,'orders_line_items_tax_lines'))

        # orders_shipping_lines
        orders_shipping_lines_detail_list = [Helper.flatten_dict({"order_id": entry['id'], **ele})
                                for entry in ordDict  if entry.get('shipping_lines')
                                for ele in entry['shipping_lines']
                                ]
        attribute_names = ['order_id', 'id', 'carrier_identifier', 'code', 'discounted_price', 'discounted_price_set_shop_money_amount', 
                              'discounted_price_set_shop_money_currency_code', 'discounted_price_set_presentment_money_amount', 
                              'discounted_price_set_presentment_money_currency_code', 'phone', 'price', 'price_set_shop_money_amount', 
                              'price_set_shop_money_currency_code', 'price_set_presentment_money_amount', 'price_set_presentment_money_currency_code', 
                              'requested_fulfillment_service_id', 'source', 'title']
        orders_shipping_lines_list = Helper.filter_list_of_dicts_by_attributes(orders_shipping_lines_detail_list, attribute_names)
        #orders_shipping_lines_list = [{k: v for (k,v) in l.items() if not isinstance(v,dict) and not isinstance(v,list)} for l in orders_shipping_lines_detail_list]
        if len(orders_shipping_lines_list)>0:
                files.append(Helper.to_csv(orders_shipping_lines_list,landing_path,'orders_shipping_lines'))
        
        # orders_shipping_lines_tax_lines_list = [ Helper.flatten_dict({"order_id": entry['order_id'],"shipping_line_id": entry['id'], **ele} )
        #                                 for entry in orders_shipping_lines_detail_list  if entry.get('tax_lines')
        #                                 for ele in entry['tax_lines']
        #                                 ]
        # if len(orders_shipping_lines_tax_lines_list)>0:
        #         files.append(Helper.to_csv(orders_shipping_lines_tax_lines_list,landing_path,'orders_shipping_lines_tax_lines'))

        # Order Risks
        # order_risks_list = []
        # for ord in ordList:
        #         new_api_base_url = api_base_url + r'orders/' + str(ord['id']) + r'/'
        #         order_risks_list.extend(ShopifyData.get_data(access_token,new_api_base_url,'risks',params,log_file_path))
       
        # if len(order_risks_list)>0:
        #         files.append(Helper.to_csv(order_risks_list,landing_path,'orders_risks'))
        
        # Order Refunds
        # order_refunds_detail_list = []
        # for ord in ordList:
        #         new_api_base_url = api_base_url + r'orders/' + str(ord['id']) + r'/'
        #         order_refunds_detail_list.extend(ShopifyData.get_data(access_token,new_api_base_url,'refunds',params,log_file_path))
       
        # order_refunds_detail_list = [Helper.flatten_dict(item) for item in order_refunds_detail_list]
        # order_refunds_list = [{k: v for (k,v) in l.items() if not isinstance(v,dict) and not isinstance(v,list)} for l in order_refunds_detail_list]
        # if len(order_refunds_list)>0:
        #         files.append(Helper.to_csv(order_refunds_list,landing_path,'orders_refunds'))

        # orders_refund_line_items_detail_list = [Helper.flatten_dict({"refund_id": entry['id'], "order_id":entry['order_id'] **ele})
        #                         for entry in order_refunds_detail_list  if entry.get('refund_line_items')
        #                         for ele in entry['refund_line_items']
        #                         ]
        # orders_refund_line_items_list = [{k: v for (k,v) in l.items() if not isinstance(v,dict) and not isinstance(v,list)} for l in orders_refund_line_items_detail_list]
        # if len(orders_refund_line_items_list)>0:
        #         files.append(Helper.to_csv(orders_refund_line_items_list,landing_path,'orders_refund_line_items'))

        # orders_refund_transactions_list = [Helper.flatten_dict({"refund_id": entry['id'], "order_id":entry['order_id'] **ele})
        #                         for entry in order_refunds_detail_list  if entry.get('transactions')
        #                         for ele in entry['transactions']
        #                         ]
        # if len(orders_refund_transactions_list)>0:
        #         files.append(Helper.to_csv(orders_refund_transactions_list,landing_path,'orders_refunds_transactions'))

        # Transactions
        # order_transaction_list = []
        # cntr = 0
        # attribute_names = ['id', 'order_id', 'kind', 'gateway', 'status', 'message', 'created_at', 'test', 'authorization', 'location_id', 'user_id', 'parent_id', 
        #                    'processed_at', 'device_id', 'error_code', 'source_name', 'payment_details_credit_card_bin', 'payment_details_avs_result_code', 
        #                    'payment_details_cvv_result_code', 'payment_details_credit_card_number', 'payment_details_credit_card_company', 
        #                    'payment_details_buyer_action_info', 'payment_details_credit_card_name', 'payment_details_credit_card_wallet', 
        #                    'payment_details_credit_card_expiration_month', 'payment_details_credit_card_expiration_year', 'payment_details_payment_method_name', 
        #                    'receipt_id', 'receipt_object', 'receipt_amount', 'receipt_amount_capturable', 'receipt_amount_received', 'receipt_canceled_at', 
        #                    'receipt_cancellation_reason', 'receipt_capture_method', 'receipt_charges_object', 'receipt_charges_data', 'receipt_charges_has_more', 
        #                    'receipt_charges_total_count', 'receipt_charges_url', 'receipt_confirmation_method', 'receipt_created', 'receipt_currency', 
        #                    'receipt_last_payment_error', 'receipt_livemode', 'receipt_metadata_email', 'receipt_metadata_manual_entry', 'receipt_metadata_order_id', 
        #                    'receipt_metadata_order_transaction_id', 'receipt_metadata_payments_charge_id', 'receipt_metadata_shop_id', 'receipt_metadata_shop_name', 
        #                    'receipt_metadata_transaction_fee_tax_amount', 'receipt_metadata_transaction_fee_total_amount', 'receipt_next_action', 
        #                    'receipt_payment_method', 'receipt_payment_method_types', 'receipt_source', 'receipt_status', 'amount', 'currency', 'payment_id', 
        #                    'total_unsettled_set_presentment_money_amount', 'total_unsettled_set_presentment_money_currency', 'total_unsettled_set_shop_money_amount', 
        #                    'total_unsettled_set_shop_money_currency', 'admin_graphql_api_id']

        # for ord in ordList:
        #         new_api_base_url = api_base_url + r'orders/' + str(ord['id']) + r'/'
        #         order_transaction_list.extend(ShopifyData.get_data(access_token,new_api_base_url,'transactions',params,log_file_path))
        #         cntr = cntr +1
        #         if cntr % 50 == 0:
        #                 order_transaction_list = [Helper.flatten_dict(item) for item in order_transaction_list]
        #                 order_transaction_list = Helper.filter_list_of_dicts_by_attributes(order_transaction_list, attribute_names)
        #                 if len(order_transaction_list)>0:
        #                         files.append(Helper.to_csv(order_transaction_list,landing_path,'orders_transactions'))
        #                 order_transaction_list = []
        #                 time.sleep(60)
       
        # order_transaction_list = [Helper.flatten_dict(item) for item in order_transaction_list]
        # order_transaction_list = Helper.filter_list_of_dicts_by_attributes(order_transaction_list, attribute_names)
        # if len(order_transaction_list)>0:
        #         files.append(Helper.to_csv(order_transaction_list,landing_path,'orders_transactions'))
        
        # Fulfillment Orders
        # fulfillment_orders_detail_list = []
        # cntr = 0
        # attribute_names = ['id', 'shop_id', 'order_id', 'assigned_location_id', 'request_status', 'status', 'supported_actions', 'destination_id', 
        #                    'destination_address1', 'destination_address2', 'destination_city', 'destination_company', 'destination_country', 'destination_email', 
        #                    'destination_first_name', 'destination_last_name', 'destination_phone', 'destination_province', 'destination_zip', 'international_duties', 
        #                    'fulfill_at', 'fulfill_by', 'fulfillment_holds', 'created_at', 'updated_at', 'delivery_method_id', 'delivery_method_method_type', 
        #                    'delivery_method_min_delivery_date_time', 'delivery_method_max_delivery_date_time', 'assigned_location_address1', 
        #                    'assigned_location_address2', 'assigned_location_city', 'assigned_location_country_code', 'assigned_location_location_id', 
        #                    'assigned_location_name', 'assigned_location_phone', 'assigned_location_province', 'assigned_location_zip', 'merchant_requests', 
        #                    'destination']

        # for ord in ordList:
        #         new_api_base_url = api_base_url + r'orders/' + str(ord['id']) + r'/'
        #         fulfillment_orders_detail_list.extend(ShopifyData.get_data(access_token,new_api_base_url,'fulfillment_orders',params,log_file_path))
        #         cntr = cntr +1
        #         if cntr % 50 == 0:
        #                 fulfillment_orders_detail_list = [Helper.flatten_dict(item) for item in fulfillment_orders_detail_list]
        #                 fulfillment_orders_list = [{key: value for key, value in d.items() if key != "line_items"} for d in fulfillment_orders_detail_list]
        #                 fulfillment_orders_list = Helper.filter_list_of_dicts_by_attributes(fulfillment_orders_list, attribute_names)
        #                 if len(fulfillment_orders_list)>0:
        #                         files.append(Helper.to_csv(fulfillment_orders_list,landing_path,'fulfillment_orders'))
        #                 fulfillment_orders_detail_list = []
        #                 time.sleep(60)
       
        # fulfillment_orders_detail_list = [Helper.flatten_dict(item) for item in fulfillment_orders_detail_list]
        # fulfillment_orders_list = [{key: value for key, value in d.items() if key != "line_items"} for d in fulfillment_orders_detail_list]
        
        # fulfillment_orders_list = Helper.filter_list_of_dicts_by_attributes(fulfillment_orders_list, attribute_names)
        # if len(fulfillment_orders_list)>0:
        #         files.append(Helper.to_csv(fulfillment_orders_list,landing_path,'fulfillment_orders'))
        
        # fulfillment_order_line_items_list =[ele 
        #                       for entry in fulfillment_orders_detail_list if entry.get('line_items')
        #                                     for ele in entry['line_items']
        #                       ]
        # if len(fulfillment_order_line_items_list)>0:
        #         files.append(Helper.to_csv(fulfillment_order_line_items_list,landing_path,'fulfillment_order_line_items'))

        # Fulfillment 
        # fulfillments_detail_list = []
        # for ord in ordList:
        #         new_api_base_url = api_base_url + r'orders/' + str(ord['id']) + r'/'
        #         fulfillments_detail_list.extend(ShopifyData.get_data(access_token,new_api_base_url,'fulfillments',params,log_file_path))
       
        # fulfillments_detail_list = [Helper.flatten_dict(item) for item in fulfillments_detail_list]
        # fulfillments_list = [{key: value for key, value in d.items() if key != "line_items"} for d in fulfillments_detail_list]
        # if len(fulfillments_list)>0:
        #         files.append(Helper.to_csv(fulfillments_list,landing_path,'fulfillments'))
        
        # fulfillments_line_items_detail_list =[ Helper.flatten_dict({ "fulfillment_id": entry['id'],"order_id":entry['order_id'], **ele} )
	# 									for entry in fulfillments_detail_list if entry.get('line_items')
	# 									for ele in entry['line_items']
	# 								  ]
        # fulfillments_line_items_list = [{key: value for key, value in d.items() if key != "properties" and key != "discount_allocations" and key != "tax_lines"} for d in 			fulfillments_line_items_detail_list]
        # if len(fulfillments_line_items_list)>0:
        #         files.append(Helper.to_csv(fulfillments_line_items_list,landing_path,'fulfillments_line_items'))

        # fulfillments_line_items_properties_list =[ { "fulfillment_line_item_id":entry['id'], "fulfillment_id": entry['fulfillment_id'],"order_id":entry['order_id'], **ele}
        #                         for entry in fulfillments_line_items_detail_list if entry.get('properties')
        #                         for ele in entry['properties']
        #                       ]
        # if len(fulfillments_line_items_properties_list)>0:
        #         files.append(Helper.to_csv(fulfillments_line_items_properties_list,landing_path,'fulfillments_line_items_properties'))

        # fulfillments_line_items_discount_allocations_list =[ Helper.flatten_dict({ "fulfillment_line_item_id":entry['id'], "fulfillment_id": entry['fulfillment_id'],"order_id":entry['order_id'], **ele})
        #                         for entry in fulfillments_line_items_detail_list if entry.get('discount_allocations')
        #                         for ele in entry['discount_allocations']
        #                         ]
        # if len(fulfillments_line_items_discount_allocations_list)>0:
        #         files.append(Helper.to_csv(fulfillments_line_items_discount_allocations_list,landing_path,'fulfillments_line_items_discount_allocations'))							  
		
        # fulfillments_line_items_tax_lines_list =[ Helper.flatten_dict({ "fulfillment_line_item_id":entry['id'], "fulfillment_id": entry['fulfillment_id'],"order_id":entry['order_id'], **ele})
        #                         for entry in fulfillments_line_items_detail_list if entry.get('tax_lines')
        #                         for ele in entry['tax_lines']
        #                                         ]
        # if len(fulfillments_line_items_tax_lines_list)>0:
        #         files.append(Helper.to_csv(fulfillments_line_items_tax_lines_list,landing_path,'fulfillments_line_items_tax_lines'))

        # FulfillmentEvent
        # fulfillment_events_list = []
        # for fulfillment in fulfillments_list:
        #         new_api_base_url = api_base_url + r'orders/' + str(fulfillment['order_id']) + r'/fulfillments/' +  str(fulfillment['id']) + r'/'
        #         fulfillment_events_list.extend(ShopifyData.get_data(access_token,new_api_base_url,'events',params,log_file_path,'fulfillment_events'))
       
        # if len(fulfillment_events_list)>0:
        #         files.append(Helper.to_csv(fulfillment_events_list,landing_path,'fulfillment_events'))
        
        #build header info
        file_info={}
        file_info['files'] = files
        # file_info['order_transaction_record_count']= len(order_transaction_list)
        # file_info['fulfillment_orders_record_count']= len(fulfillment_orders_list)
        file_info['incremental_load_record_count']= len(ordDict)
        return file_info

# def get_draft_orders(access_token,api_base_url,params,landing_path,save_raw=False,raw_file_path='',log_file_path=''):
#         files=[]
#         ordDict = ShopifyData.get_data(access_token,api_base_url,'draft_orders',params,log_file_path)

#         if save_raw == True:
#                 files.append(Helper.to_json(ordDict, raw_file_path,'draft_orders',True))

#         #1.0 draft_orders
#         ordList = [{k: v for (k,v) in l.items() if not isinstance(v,dict) and not isinstance(v,list)} for l in ordDict]
#         files.append(Helper.to_csv(ordList,landing_path,'draft_orders'))

#         #1.1 line_items including children tables
#         draft_orders_tax_lines_list =[Helper.flatten_dict({"draft_order_id": entry['id'], **ele})
#                                 for entry in ordDict if entry.get('tax_lines')
#                                 for ele in entry['tax_lines']
#                                 ]
#         files.append(Helper.to_csv(draft_orders_tax_lines_list,landing_path,'draft_orders_tax_lines'))
        
#         draft_orders_shipping_address_list = [ {"draft_order_id":entry['id'], **entry['shipping_address']} 
#                                for entry in ordDict if entry.get('shipping_address')
#                               ]
#         files.append(Helper.to_csv(draft_orders_shipping_address_list,landing_path,'draft_orders_shipping_address'))
        
#         draft_orders_billing_address_list = [ {"draft_order_id":entry['id'], **entry['billing_address']} 
#                                for entry in ordDict if entry.get('billing_address')
#                               ]
#         files.append(Helper.to_csv(draft_orders_billing_address_list,landing_path,'draft_orders_billing_address'))

#         draft_orders_customer_list = [Helper.flatten_dict( {"draft_order_id":entry['id'], **entry['customer']} )
#                                for entry in ordDict  if entry.get('customer')
#                               ]
#         files.append(Helper.to_csv(draft_orders_customer_list,landing_path,'draft_orders_customer'))

#         draft_orders_line_items_detail_list = [Helper.flatten_dict({"draft_order_id": entry['id'], **ele})
#                                 for entry in ordDict  if entry.get('line_items')
#                                 for ele in entry['line_items']
#                                 ]
#         draft_orders_line_items_list = [{k: v for (k,v) in l.items() if not isinstance(v,dict) and not isinstance(v,list)} for l in draft_orders_line_items_detail_list]
#         files.append(Helper.to_csv(draft_orders_line_items_list,landing_path,'draft_orders_line_items'))
        
#         draft_orders_line_items_tax_lines_list = [ Helper.flatten_dict({"draft_order_id": entry['draft_order_id'],"line_item_id": entry['id'], **ele} )
#                                         for entry in draft_orders_line_items_detail_list  if entry.get('tax_lines')
#                                         for ele in entry['tax_lines']
#                                         ]
#         files.append(Helper.to_csv(draft_orders_line_items_tax_lines_list,landing_path,'draft_orders_line_items_tax_lines'))


#         draft_orders_shipping_lines_detail_list = [Helper.flatten_dict({"draft_order_id": entry['id'], **ele})
#                                 for entry in ordDict  if entry.get('shipping_lines')
#                                 for ele in entry['shipping_lines']
#                                 ]
#         draft_orders_shipping_lines_list = [{k: v for (k,v) in l.items() if not isinstance(v,dict) and not isinstance(v,list)} for l in draft_orders_shipping_lines_detail_list]
#         files.append(Helper.to_csv(draft_orders_shipping_lines_list,landing_path,'draft_orders_shipping_lines'))
        
#         draft_orders_shipping_lines_tax_lines_list = [ Helper.flatten_dict({"draft_order_id": entry['draft_order_id'],"shipping_line_id": entry['id'], **ele} )
#                                         for entry in draft_orders_shipping_lines_detail_list  if entry.get('tax_lines')
#                                         for ele in entry['tax_lines']
#                                         ]
#         files.append(Helper.to_csv(draft_orders_shipping_lines_tax_lines_list,landing_path,'draft_orders_shipping_lines_tax_lines'))

#         #build header info
#         file_info={}
#         file_info['files'] = files
#         file_info['incremental_load_record_count']= len(ordDict)
#         return file_info

def get_checkouts(access_token,api_base_url,params,landing_path,save_raw=False,raw_file_path='',log_file_path=''):
        files=[]

        chkDict = ShopifyData.get_data(access_token,api_base_url,'checkouts',params,log_file_path)

        if save_raw == True:
                files.append(Helper.to_json(chkDict, raw_file_path,'checkouts',True))

        #1.0 checkouts
        attribute_names = ['id', 'token', 'cart_token', 'email', 'gateway', 'buyer_accepts_marketing', 'created_at', 'updated_at', 
                              'landing_site', 'note', 'referring_site', 'taxes_included', 'total_weight', 'currency', 'completed_at', 
                              'closed_at', 'user_id', 'location_id', 'source_identifier', 'source_url', 'device_id', 'phone', 
                              'customer_locale', 'name', 'source', 'abandoned_checkout_url', 'source_name', 'presentment_currency', 
                              'buyer_accepts_sms_marketing', 'sms_marketing_phone', 'total_discounts', 'total_line_items_price', 
                              'total_price', 'total_tax', 'subtotal_price', 'total_duties']
        chkList = Helper.filter_list_of_dicts_by_attributes(chkDict, attribute_names)
        #chkList = [{k: v for (k,v) in l.items() if not isinstance(v,dict) and not isinstance(v,list)} for l in chkDict]
        if len(chkList)>0:
                files.append(Helper.to_csv(chkList,landing_path,'checkouts'))

        #1.1 shipping_lines including children tables
        # checkouts_tax_lines_list =[Helper.flatten_dict({"checkout_id": entry['id'], **ele})
        #                         for entry in chkDict if entry.get('tax_lines')
        #                         for ele in entry['tax_lines']
        #                         ]
        # if len(checkouts_tax_lines_list)>0:
        #         files.append(Helper.to_csv(checkouts_tax_lines_list,landing_path,'checkouts_tax_lines'))
        
        # checkouts_billing_address
        checkouts_billing_address_list = [ {"checkout_id":entry['id'], **entry['billing_address']} 
                               for entry in chkDict if entry.get('billing_address')
                              ]
        attribute_names=['checkout_id', 'first_name', 'address1', 'phone', 'city', 'zip', 'province', 'country', 'last_name', 'address2', 'company', 
                         'latitude', 'longitude', 'name', 'country_code', 'province_code']
        checkouts_billing_address_list = Helper.filter_list_of_dicts_by_attributes(checkouts_billing_address_list, attribute_names)
        if len(checkouts_billing_address_list)>0:
                files.append(Helper.to_csv(checkouts_billing_address_list,landing_path,'checkouts_billing_address'))
        
        # checkouts_shipping_address
        checkouts_shipping_address_list = [ {"checkout_id":entry['id'], **entry['shipping_address']} 
                               for entry in chkDict if entry.get('shipping_address')
                              ]
        attribute_names = ['checkout_id', 'first_name', 'address1', 'phone', 'city', 'zip', 'province', 'country', 'last_name', 'address2', 'company', 
                           'latitude', 'longitude', 'name', 'country_code', 'province_code']
        checkouts_shipping_address_list = Helper.filter_list_of_dicts_by_attributes(checkouts_shipping_address_list, attribute_names)
        if len(checkouts_shipping_address_list)>0:
                files.append(Helper.to_csv(checkouts_shipping_address_list,landing_path,'checkouts_shipping_address'))

        # checkouts_customer
        checkouts_customer_list = [Helper.flatten_dict( {"checkout_id":entry['id'], **entry['customer']} )
                               for entry in chkDict  if entry.get('customer')
                              ]
        attribute_names = ['checkout_id', 'id', 'email', 'created_at', 'updated_at', 'first_name', 'last_name', 'orders_count', 'state', 'total_spent', 
                           'last_order_id', 'note', 'verified_email', 'multipass_identifier', 'tax_exempt', 'tags', 'last_order_name', 'currency', 'phone', 
                           'accepts_marketing', 'accepts_marketing_updated_at', 'marketing_opt_in_level', 'tax_exemptions', 'email_marketing_consent_state', 
                           'email_marketing_consent_opt_in_level', 'email_marketing_consent_consent_updated_at', 'sms_marketing_consent', 'admin_graphql_api_id',
                           'default_address_id', 'default_address_customer_id', 'default_address_first_name', 'default_address_last_name', 'default_address_company', 
                           'default_address_address1', 'default_address_address2', 'default_address_city', 'default_address_province', 'default_address_country', 
                           'default_address_zip', 'default_address_phone', 'default_address_name', 'default_address_province_code', 'default_address_country_code', 
                           'default_address_country_name', 'default_address_default','sms_marketing_consent_state', 'sms_marketing_consent_opt_in_level', 
                           'sms_marketing_consent_consent_updated_at', 'sms_marketing_consent_consent_collected_from']
        checkouts_customer_list = Helper.filter_list_of_dicts_by_attributes(checkouts_customer_list, attribute_names)
        if len(checkouts_customer_list)>0:
                files.append(Helper.to_csv(checkouts_customer_list,landing_path,'checkouts_customer'))

        checkouts_line_items_detail_list = [Helper.flatten_dict({"checkout_id": entry['id'], **ele})
                                for entry in chkDict  if entry.get('line_items')
                                for ele in entry['line_items']
                                ]
        attribute_names=['checkout_id', 'key', 'destination_location_id', 'fulfillment_service', 'gift_card', 'grams', 
                            'origin_location_id', 'presentment_title', 'presentment_variant_title', 'product_id', 'quantity', 
                            'requires_shipping', 'sku', 'taxable', 'title', 'variant_id', 'variant_title', 'variant_price', 
                            'vendor', 'user_id', 'unit_price_measurement_measured_type', 'unit_price_measurement_quantity_value', 
                            'unit_price_measurement_quantity_unit', 'unit_price_measurement_reference_value', 
                            'unit_price_measurement_reference_unit', 'rank', 'compare_at_price', 'line_price', 'price', 
                            'tax_code', 'id', 'selling_plan_application_selling_plan_id', 'selling_plan_application_api_client_id', 
                            'selling_plan_application_name', 'selling_plan_application_description', 
                            'selling_plan_application_reporting_label', 'selling_plan_application_billing_interval', 
                            'selling_plan_application_billing_interval_count', 'selling_plan_application_billing_min_cycles', 
                            'selling_plan_application_billing_max_cycles', 'selling_plan_application_delivery_interval', 
                            'selling_plan_application_delivery_interval_count', 'selling_plan_application_delivery_cutoff_period', 
                            'selling_plan_application_delivery_pre_cutoff_behavior', 'selling_plan_application_delivery_intent', 
                            'selling_plan_id']
        checkouts_line_items_list = Helper.filter_list_of_dicts_by_attributes(checkouts_line_items_detail_list, attribute_names)
        #checkouts_line_items_list = [{k: v for (k,v) in l.items() if not isinstance(v,dict) and not isinstance(v,list)} for l in checkouts_line_items_detail_list]
        if len(checkouts_line_items_list)>0:
                files.append(Helper.to_csv(checkouts_line_items_list,landing_path,'checkouts_line_items'))
        
        # checkouts_line_items_tax_lines_list = [ Helper.flatten_dict({"checkout_id": entry['checkout_id'],"line_item_id": entry['id'], **ele} )
        #                                 for entry in checkouts_line_items_detail_list  if entry.get('tax_lines')
        #                                 for ele in entry['tax_lines']
        #                                 ]
        # if len(checkouts_line_items_tax_lines_list)>0:
        #         files.append(Helper.to_csv(checkouts_line_items_tax_lines_list,landing_path,'checkouts_line_items_tax_lines'))

        checkouts_shipping_lines_detail_list = [Helper.flatten_dict({"checkout_id": entry['id'], **ele})
                                for entry in chkDict  if entry.get('shipping_lines')
                                for ele in entry['shipping_lines']
                                ]
        attribute_names=['checkout_id', 'code', 'price', 'original_shop_price', 'original_rate_price', 'original_shop_markup', 
                            'source', 'title', 'presentment_title', 'phone', 'custom_tax_lines', 'validation_context', 'markup', 
                            'delivery_category', 'carrier_identifier', 'carrier_service_id', 'api_client_id', 
                            'requested_fulfillment_service_id', 'delivery_option_group_type', 'delivery_expectation_range', 
                            'delivery_expectation_type', 'estimated_delivery_time_range', 'id', 'delivery_option_group_token']
        checkouts_shipping_lines_list = Helper.filter_list_of_dicts_by_attributes(checkouts_shipping_lines_detail_list, attribute_names)
        #checkouts_shipping_lines_list = [{k: v for (k,v) in l.items() if not isinstance(v,dict) and not isinstance(v,list)} for l in checkouts_shipping_lines_detail_list]
        if len(checkouts_shipping_lines_list)>0:
                files.append(Helper.to_csv(checkouts_shipping_lines_list,landing_path,'checkouts_shipping_lines'))
        
        # checkouts_shipping_lines_tax_lines_list = [ Helper.flatten_dict({"checkout_id": entry['checkout_id'],"shipping_line_id": entry['id'], **ele} )
        #                                 for entry in checkouts_shipping_lines_detail_list  if entry.get('tax_lines')
        #                                 for ele in entry['tax_lines']
        #                                 ]
        # if len(checkouts_shipping_lines_tax_lines_list)>0:
        #         files.append(Helper.to_csv(checkouts_shipping_lines_tax_lines_list,landing_path,'checkouts_shipping_lines_tax_lines'))
        #build header info
        file_info={}
        file_info['files'] = files
        file_info['incremental_load_record_count']= len(chkDict)
        return file_info