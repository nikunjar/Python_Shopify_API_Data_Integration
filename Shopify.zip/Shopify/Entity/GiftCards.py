import pandas as pd
from datetime import datetime
import ShopifyData, Helper

def get_gift_cards(access_token,api_base_url,params,landing_path,save_raw=False,raw_file_path='',log_file_path=''):
        files=[]
        giftcards_list = ShopifyData.get_data(access_token,api_base_url,'gift_cards',params,log_file_path)

        attribute_names = ['id', 'balance', 'created_at', 'updated_at', 'currency', 'initial_value', 'disabled_at', 'line_item_id', 'api_client_id', 
             'user_id', 'customer_id', 'note', 'expires_on', 'template_suffix', 'last_characters', 'order_id']
        giftcards_list = Helper.filter_list_of_dicts_by_attributes(giftcards_list, attribute_names)

        if save_raw == True:
                files.append(Helper.to_json(giftcards_list, raw_file_path,'gift_cards',True))

        if len(giftcards_list)>0:
                files.append(Helper.to_csv(giftcards_list,landing_path,'gift_cards'))

        #build header info
        file_info={}
        file_info['files'] = files
        file_info['incremental_load_record_count']= len(giftcards_list)
        return file_info